package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        GameEntity::class,
        GameProfileEntity::class,
        GamingSessionEntity::class,
        AppSettingEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class GameTurboDatabase : RoomDatabase() {
    abstract fun gameDao(): GameDao
    abstract fun gameProfileDao(): GameProfileDao
    abstract fun gamingSessionDao(): GamingSessionDao
    abstract fun appSettingDao(): AppSettingDao

    companion object {
        @Volatile
        private var INSTANCE: GameTurboDatabase? = null

        fun getDatabase(context: Context): GameTurboDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    GameTurboDatabase::class.java,
                    "game_turbo_database.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
