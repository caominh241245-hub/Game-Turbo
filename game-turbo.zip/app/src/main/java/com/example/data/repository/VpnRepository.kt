package com.example.data.repository

import android.content.Context
import com.example.data.model.VpnServer
import com.example.data.model.VpnSessionState
import com.example.data.model.VpnStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.random.Random

class VpnRepository(private val context: Context) {

    private val _servers = MutableStateFlow<List<VpnServer>>(emptyList())
    val servers: StateFlow<List<VpnServer>> = _servers.asStateFlow()

    private val _sessionState = MutableStateFlow(VpnSessionState())
    val sessionState: StateFlow<VpnSessionState> = _sessionState.asStateFlow()

    private val scope = CoroutineScope(Dispatchers.Default)
    private var timerJob: Job? = null

    init {
        loadServerList()
    }

    private fun loadServerList() {
        val serverList = listOf(
            VpnServer(
                id = "vn_hn_01",
                countryCode = "VN",
                countryNameVn = "Việt Nam",
                countryNameEn = "Vietnam",
                cityVn = "Hà Nội (Gaming Cáp Quang)",
                cityEn = "Hanoi (Fiber Gaming Node)",
                flagEmoji = "🇻🇳",
                ipAddress = "103.142.26.88",
                basePingMs = 9,
                isRecommended = true,
                isPrioritized = true
            ),
            VpnServer(
                id = "vn_hcm_02",
                countryCode = "VN",
                countryNameVn = "Việt Nam",
                countryNameEn = "Vietnam",
                cityVn = "TP. Hồ Chí Minh (Tuyển thủ Pro)",
                cityEn = "Ho Chi Minh City (eSports Direct)",
                flagEmoji = "🇻🇳",
                ipAddress = "103.1.238.10",
                basePingMs = 12,
                isRecommended = true,
                isPrioritized = true
            ),
            VpnServer(
                id = "sg_01",
                countryCode = "SG",
                countryNameVn = "Singapore",
                countryNameEn = "Singapore",
                cityVn = "Singapore (SEA Tuyến Quốc Tế)",
                cityEn = "Singapore (SEA Core Gateway)",
                flagEmoji = "🇸🇬",
                ipAddress = "139.180.200.15",
                basePingMs = 24,
                isRecommended = true
            ),
            VpnServer(
                id = "th_01",
                countryCode = "TH",
                countryNameVn = "Thái Lan",
                countryNameEn = "Thailand",
                cityVn = "Bangkok (Đông Nam Á 1)",
                cityEn = "Bangkok (SEA 1)",
                flagEmoji = "🇹🇭",
                ipAddress = "119.59.100.22",
                basePingMs = 29
            ),
            VpnServer(
                id = "id_01",
                countryCode = "ID",
                countryNameVn = "Indonesia",
                countryNameEn = "Indonesia",
                cityVn = "Jakarta (Máy chủ Game Indo)",
                cityEn = "Jakarta (Gaming Hub)",
                flagEmoji = "🇮🇩",
                ipAddress = "103.247.12.8",
                basePingMs = 35,
                isPrioritized = true
            ),
            VpnServer(
                id = "my_01",
                countryCode = "MY",
                countryNameVn = "Malaysia",
                countryNameEn = "Malaysia",
                cityVn = "Kuala Lumpur (Tuyến nhanh)",
                cityEn = "Kuala Lumpur (Direct)",
                flagEmoji = "🇲🇾",
                ipAddress = "175.143.10.12",
                basePingMs = 33,
                isPrioritized = true
            ),
            VpnServer(
                id = "ph_01",
                countryCode = "PH",
                countryNameVn = "Philippines",
                countryNameEn = "Philippines",
                cityVn = "Manila (Garena Server)",
                cityEn = "Manila (Gaming Gate)",
                flagEmoji = "🇵🇭",
                ipAddress = "112.198.115.4",
                basePingMs = 45
            ),
            VpnServer(
                id = "jp_01",
                countryCode = "JP",
                countryNameVn = "Nhật Bản",
                countryNameEn = "Japan",
                cityVn = "Tokyo (eSports Low-Jitter)",
                cityEn = "Tokyo (eSports Low-Jitter)",
                flagEmoji = "🇯🇵",
                ipAddress = "160.16.80.99",
                basePingMs = 48,
                isRecommended = true
            ),
            VpnServer(
                id = "kr_01",
                countryCode = "KR",
                countryNameVn = "Hàn Quốc",
                countryNameEn = "South Korea",
                cityVn = "Seoul (Tốc độ Gigabyte)",
                cityEn = "Seoul (Ultra Giga)",
                flagEmoji = "🇰🇷",
                ipAddress = "211.233.55.10",
                basePingMs = 54
            ),
            VpnServer(
                id = "us_01",
                countryCode = "US",
                countryNameVn = "Hoa Kỳ",
                countryNameEn = "United States",
                cityVn = "Los Angeles (Bờ Tây US)",
                cityEn = "Los Angeles (US West)",
                flagEmoji = "🇺🇸",
                ipAddress = "104.28.19.44",
                basePingMs = 135
            ),
            VpnServer(
                id = "de_01",
                countryCode = "DE",
                countryNameVn = "Đức",
                countryNameEn = "Germany",
                cityVn = "Frankfurt (Châu Âu Core)",
                cityEn = "Frankfurt (EU Core)",
                flagEmoji = "🇩🇪",
                ipAddress = "159.69.12.33",
                basePingMs = 145
            ),
            VpnServer(
                id = "uk_01",
                countryCode = "UK",
                countryNameVn = "Vương Quốc Anh",
                countryNameEn = "United Kingdom",
                cityVn = "London (Gaming EU West)",
                cityEn = "London (EU West Hub)",
                flagEmoji = "🇬🇧",
                ipAddress = "178.62.88.9",
                basePingMs = 152
            )
        )
        _servers.value = serverList
        _sessionState.value = _sessionState.value.copy(selectedServer = serverList.first())
    }

    fun selectServer(server: VpnServer) {
        if (_sessionState.value.status == VpnStatus.CONNECTED) {
            connectToServer(server)
        } else {
            _sessionState.value = _sessionState.value.copy(selectedServer = server)
        }
    }

    fun connectToServer(server: VpnServer? = null) {
        val targetServer = server ?: _sessionState.value.selectedServer ?: _servers.value.first()
        _sessionState.value = _sessionState.value.copy(
            status = VpnStatus.CONNECTING,
            selectedServer = targetServer
        )

        scope.launch {
            delay(1200) // Realistic handshake / tunnel negotiation
            val livePing = targetServer.basePingMs + Random.nextInt(-2, 3)
            _sessionState.value = _sessionState.value.copy(
                status = VpnStatus.CONNECTED,
                currentPingMs = livePing,
                durationSeconds = 0L,
                bytesReceived = 1024L * 512,
                bytesSent = 1024L * 128
            )
            startSessionTicker()
        }
    }

    fun disconnect() {
        _sessionState.value = _sessionState.value.copy(status = VpnStatus.DISCONNECTING)
        timerJob?.cancel()
        scope.launch {
            delay(600)
            _sessionState.value = _sessionState.value.copy(
                status = VpnStatus.DISCONNECTED,
                durationSeconds = 0L,
                currentPingMs = 0
            )
        }
    }

    private fun startSessionTicker() {
        timerJob?.cancel()
        timerJob = scope.launch {
            while (isActive && _sessionState.value.status == VpnStatus.CONNECTED) {
                delay(1000)
                val current = _sessionState.value
                val base = current.selectedServer?.basePingMs ?: 20
                _sessionState.value = current.copy(
                    durationSeconds = current.durationSeconds + 1,
                    currentPingMs = (base + Random.nextInt(-1, 3)).coerceAtLeast(5),
                    bytesReceived = current.bytesReceived + Random.nextLong(15000, 65000),
                    bytesSent = current.bytesSent + Random.nextLong(5000, 25000)
                )
            }
        }
    }
}
