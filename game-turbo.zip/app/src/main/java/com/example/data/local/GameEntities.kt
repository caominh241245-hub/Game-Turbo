package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "games")
data class GameEntity(
    @PrimaryKey
    val packageName: String,
    val appName: String,
    val isCustom: Boolean = false,
    val isFavorite: Boolean = false,
    val lastPlayedTimestamp: Long = 0L,
    val totalPlayTimeSeconds: Long = 0L,
    val orderIndex: Int = 0
)

@Entity(tableName = "game_profiles")
data class GameProfileEntity(
    @PrimaryKey
    val packageName: String,
    val performanceMode: String = "PERFORMANCE", // PERFORMANCE, BALANCED, BATTERY_SAVER
    val targetRefreshRate: Int = 120, // 0 = Auto/Max, 60, 90, 120, 144
    val dndEnabled: Boolean = true,
    val touchOptimization: Boolean = true,
    val floatingBarEnabled: Boolean = true,
    val cleanRamOnLaunch: Boolean = true,
    val networkBoostEnabled: Boolean = true,
    val autoVpnCountry: String = "Việt Nam",
    val brightnessPercent: Int = 85
)

@Entity(tableName = "gaming_sessions")
data class GamingSessionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val packageName: String,
    val appName: String,
    val startTime: Long,
    val endTime: Long,
    val durationSeconds: Long,
    val avgFps: Int,
    val avgPing: Int,
    val maxTemp: Float,
    val batteryDrainPercent: Int
)

@Entity(tableName = "app_settings")
data class AppSettingEntity(
    @PrimaryKey
    val key: String,
    val value: String
)
