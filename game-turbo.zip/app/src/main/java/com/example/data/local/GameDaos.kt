package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface GameDao {
    @Query("SELECT * FROM games ORDER BY isFavorite DESC, lastPlayedTimestamp DESC, orderIndex ASC")
    fun getAllGames(): Flow<List<GameEntity>>

    @Query("SELECT * FROM games WHERE packageName = :packageName LIMIT 1")
    suspend fun getGame(packageName: String): GameEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGame(game: GameEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGames(games: List<GameEntity>)

    @Update
    suspend fun updateGame(game: GameEntity)

    @Query("DELETE FROM games WHERE packageName = :packageName")
    suspend fun deleteGame(packageName: String)

    @Query("UPDATE games SET lastPlayedTimestamp = :timestamp, totalPlayTimeSeconds = totalPlayTimeSeconds + :addedSeconds WHERE packageName = :packageName")
    suspend fun updatePlayTime(packageName: String, timestamp: Long, addedSeconds: Long)
}

@Dao
interface GameProfileDao {
    @Query("SELECT * FROM game_profiles WHERE packageName = :packageName LIMIT 1")
    fun getProfileFlow(packageName: String): Flow<GameProfileEntity?>

    @Query("SELECT * FROM game_profiles WHERE packageName = :packageName LIMIT 1")
    suspend fun getProfile(packageName: String): GameProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProfile(profile: GameProfileEntity)

    @Query("DELETE FROM game_profiles WHERE packageName = :packageName")
    suspend fun deleteProfile(packageName: String)
}

@Dao
interface GamingSessionDao {
    @Query("SELECT * FROM gaming_sessions ORDER BY startTime DESC LIMIT 50")
    fun getRecentSessions(): Flow<List<GamingSessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: GamingSessionEntity)

    @Query("SELECT SUM(durationSeconds) FROM gaming_sessions")
    fun getTotalGamingSeconds(): Flow<Long?>

    @Query("SELECT COUNT(*) FROM gaming_sessions")
    fun getTotalSessionsCount(): Flow<Int>

    @Query("DELETE FROM gaming_sessions")
    suspend fun clearAllSessions()
}

@Dao
interface AppSettingDao {
    @Query("SELECT value FROM app_settings WHERE `key` = :key LIMIT 1")
    suspend fun getSetting(key: String): String?

    @Query("SELECT value FROM app_settings WHERE `key` = :key LIMIT 1")
    fun getSettingFlow(key: String): Flow<String?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setSetting(setting: AppSettingEntity)
}
