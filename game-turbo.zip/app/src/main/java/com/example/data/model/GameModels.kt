package com.example.data.model

import android.graphics.drawable.Drawable

data class InstalledApp(
    val packageName: String,
    val appName: String,
    val icon: Drawable? = null,
    val isGame: Boolean = false,
    val isAddedToTurbo: Boolean = false,
    val versionName: String = "1.0",
    val installTime: Long = 0L
)

enum class PerformanceMode(val displayNameVn: String, val displayNameEn: String, val descriptionVn: String, val descriptionEn: String) {
    PERFORMANCE(
        displayNameVn = "Hiệu năng cao",
        displayNameEn = "Performance",
        descriptionVn = "Ưu tiên tốc độ khung hình tối đa, giải phóng RAM, tối ưu CPU và mạng.",
        descriptionEn = "Prioritize maximum frame rates, free RAM, optimize CPU & network."
    ),
    BALANCED(
        displayNameVn = "Cân bằng",
        displayNameEn = "Balanced",
        descriptionVn = "Cân bằng giữa hiệu năng chơi game mượt mà và mức tiêu thụ pin tối ưu.",
        descriptionEn = "Balance smooth gaming performance with optimal battery life."
    ),
    BATTERY_SAVER(
        displayNameVn = "Tiết kiệm pin",
        displayNameEn = "Battery Saver",
        descriptionVn = "Giảm tải hoạt động nền, tối ưu nhiệt độ và kéo dài thời lượng chơi game.",
        descriptionEn = "Reduce background load, cool down device, and extend play time."
    )
}

enum class ThermalStatus(val titleVn: String, val titleEn: String, val colorHex: Long) {
    NORMAL("Mát mẻ (<38°C)", "Normal (<38°C)", 0xFFFFFFFF),
    WARM("Ấm nhẹ (38-42°C)", "Warm (38-42°C)", 0xFFFFFFFF),
    HOT("Nóng (43-47°C)", "Hot (43-47°C)", 0xFFFFFFFF),
    CRITICAL("Quá nhiệt (>47°C)", "Critical (>47°C)", 0xFFFFFFFF)
}

data class DeviceHardwareStats(
    val cpuUsagePercent: Int = 24,
    val cpuFrequencyGhz: Float = 2.8f,
    val gpuUsagePercent: Int = 30,
    val totalRamGb: Float = 8.0f,
    val usedRamGb: Float = 4.2f,
    val freeRamGb: Float = 3.8f,
    val ramUsagePercent: Int = 52,
    val batteryPercent: Int = 85,
    val batteryTempCelsius: Float = 36.5f,
    val isCharging: Boolean = false,
    val thermalStatus: ThermalStatus = ThermalStatus.NORMAL,
    val currentFps: Int = 60,
    val targetRefreshRate: Int = 120,
    val maxSupportedRefreshRate: Int = 120,
    val isHighRefreshRateSupported: Boolean = true,
    val pingMs: Int = 18,
    val jitterMs: Int = 3,
    val packetLossPercent: Int = 0,
    val downloadSpeedMbps: Float = 45.2f,
    val uploadSpeedMbps: Float = 22.8f,
    val networkType: String = "Wi-Fi 5GHz",
    val activePerformanceMode: PerformanceMode = PerformanceMode.PERFORMANCE
)

data class VpnServer(
    val id: String,
    val countryCode: String,
    val countryNameVn: String,
    val countryNameEn: String,
    val cityVn: String,
    val cityEn: String,
    val flagEmoji: String,
    val ipAddress: String,
    val basePingMs: Int,
    val isRecommended: Boolean = false,
    val isPrioritized: Boolean = false
)

enum class VpnStatus {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    DISCONNECTING
}

data class VpnSessionState(
    val status: VpnStatus = VpnStatus.DISCONNECTED,
    val selectedServer: VpnServer? = null,
    val currentPingMs: Int = 0,
    val durationSeconds: Long = 0L,
    val bytesReceived: Long = 0L,
    val bytesSent: Long = 0L
)

data class StorageCleanStats(
    val totalStorageGb: Float = 128.0f,
    val usedStorageGb: Float = 64.5f,
    val freeStorageGb: Float = 63.5f,
    val appCacheMb: Long = 420L,
    val tempFilesMb: Long = 280L,
    val apkResidueMb: Long = 150L,
    val ramFreedMb: Long = 0L,
    val lastCleanTimestamp: Long = 0L
)
