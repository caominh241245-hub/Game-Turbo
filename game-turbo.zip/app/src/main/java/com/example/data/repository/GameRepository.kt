package com.example.data.repository

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Build
import com.example.data.local.GameDao
import com.example.data.local.GameEntity
import com.example.data.local.GameProfileDao
import com.example.data.local.GameProfileEntity
import com.example.data.local.GamingSessionDao
import com.example.data.local.GamingSessionEntity
import com.example.data.model.InstalledApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class GameRepository(
    private val context: Context,
    private val gameDao: GameDao,
    private val profileDao: GameProfileDao,
    private val sessionDao: GamingSessionDao
) {
    private val packageManager: PackageManager = context.packageManager
    private val scope = CoroutineScope(Dispatchers.IO)

    val allGamesFlow: Flow<List<GameEntity>> = gameDao.getAllGames()
    val recentSessionsFlow: Flow<List<GamingSessionEntity>> = sessionDao.getRecentSessions()
    val totalPlaySecondsFlow: Flow<Long?> = sessionDao.getTotalGamingSeconds()
    val totalSessionsCountFlow: Flow<Int> = sessionDao.getTotalSessionsCount()

    private val _installedApps = MutableStateFlow<List<InstalledApp>>(emptyList())
    val installedApps: StateFlow<List<InstalledApp>> = _installedApps.asStateFlow()

    init {
        scope.launch {
            initializeDefaultGamesIfEmpty()
            scanInstalledApplications()
        }
    }

    private suspend fun initializeDefaultGamesIfEmpty() {
        val existing = gameDao.getAllGames().first()
        if (existing.isEmpty()) {
            val defaultGames = listOf(
                GameEntity("com.garena.game.kgvn", "Liên Quân Mobile", isCustom = false, isFavorite = true, orderIndex = 0),
                GameEntity("com.vng.pubgmobile", "PUBG Mobile VN", isCustom = false, isFavorite = true, orderIndex = 1),
                GameEntity("com.dts.freefireth", "Free Fire", isCustom = false, isFavorite = false, orderIndex = 2),
                GameEntity("com.miHoYo.GenshinImpact", "Genshin Impact", isCustom = false, isFavorite = true, orderIndex = 3),
                GameEntity("com.riotgames.league.wildriftvn", "Tốc Chiến VNG", isCustom = false, isFavorite = false, orderIndex = 4),
                GameEntity("com.vng.codmvn", "Call of Duty: Mobile VN", isCustom = false, isFavorite = false, orderIndex = 5),
                GameEntity("com.roblox.client", "Roblox", isCustom = false, isFavorite = false, orderIndex = 6)
            )
            gameDao.insertGames(defaultGames)

            // Insert default profiles for each
            for (game in defaultGames) {
                profileDao.saveProfile(
                    GameProfileEntity(
                        packageName = game.packageName,
                        performanceMode = "PERFORMANCE",
                        targetRefreshRate = 120,
                        dndEnabled = true,
                        touchOptimization = true,
                        floatingBarEnabled = true,
                        cleanRamOnLaunch = true,
                        networkBoostEnabled = true,
                        autoVpnCountry = "Việt Nam",
                        brightnessPercent = 85
                    )
                )
            }
        }
    }

    suspend fun scanInstalledApplications() = withContext(Dispatchers.IO) {
        val apps = mutableListOf<InstalledApp>()
        val mainIntent = Intent(Intent.ACTION_MAIN, null)
        mainIntent.addCategory(Intent.CATEGORY_LAUNCHER)

        val resolvedApps = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            packageManager.queryIntentActivities(mainIntent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            packageManager.queryIntentActivities(mainIntent, 0)
        }

        val currentTurboGames = gameDao.getAllGames().first().map { it.packageName }.toSet()

        for (resolveInfo in resolvedApps) {
            val pkg = resolveInfo.activityInfo.packageName
            if (pkg == context.packageName) continue

            val appName = resolveInfo.loadLabel(packageManager).toString()
            val icon = resolveInfo.loadIcon(packageManager)
            val isGameCategory = try {
                val appInfo = packageManager.getApplicationInfo(pkg, 0)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    appInfo.category == ApplicationInfo.CATEGORY_GAME
                } else {
                    false
                }
            } catch (_: Exception) {
                false
            }

            apps.add(
                InstalledApp(
                    packageName = pkg,
                    appName = appName,
                    icon = icon,
                    isGame = isGameCategory || currentTurboGames.contains(pkg),
                    isAddedToTurbo = currentTurboGames.contains(pkg)
                )
            )
        }

        _installedApps.value = apps.sortedByDescending { it.isAddedToTurbo }
    }

    fun getAppIcon(packageName: String): Drawable? {
        return try {
            packageManager.getApplicationIcon(packageName)
        } catch (_: Exception) {
            null
        }
    }

    suspend fun addGameToTurbo(packageName: String, appName: String) = withContext(Dispatchers.IO) {
        val game = GameEntity(
            packageName = packageName,
            appName = appName,
            isCustom = true,
            isFavorite = false,
            orderIndex = 99
        )
        gameDao.insertGame(game)
        profileDao.saveProfile(
            GameProfileEntity(
                packageName = packageName,
                performanceMode = "PERFORMANCE",
                targetRefreshRate = 120,
                dndEnabled = true,
                touchOptimization = true,
                floatingBarEnabled = true,
                cleanRamOnLaunch = true,
                networkBoostEnabled = true,
                autoVpnCountry = "Việt Nam",
                brightnessPercent = 85
            )
        )
        scanInstalledApplications()
    }

    suspend fun removeGameFromTurbo(packageName: String) = withContext(Dispatchers.IO) {
        gameDao.deleteGame(packageName)
        profileDao.deleteProfile(packageName)
        scanInstalledApplications()
    }

    suspend fun toggleFavorite(packageName: String, isFav: Boolean) = withContext(Dispatchers.IO) {
        val game = gameDao.getGame(packageName)
        if (game != null) {
            gameDao.updateGame(game.copy(isFavorite = isFav))
        }
    }

    fun getProfileFlow(packageName: String): Flow<GameProfileEntity?> {
        return profileDao.getProfileFlow(packageName)
    }

    suspend fun getProfile(packageName: String): GameProfileEntity {
        return profileDao.getProfile(packageName) ?: GameProfileEntity(packageName = packageName)
    }

    suspend fun saveProfile(profile: GameProfileEntity) = withContext(Dispatchers.IO) {
        profileDao.saveProfile(profile)
    }

    suspend fun recordGameSession(
        packageName: String,
        appName: String,
        startTime: Long,
        durationSeconds: Long,
        avgFps: Int,
        avgPing: Int,
        maxTemp: Float,
        batteryDrain: Int
    ) = withContext(Dispatchers.IO) {
        val session = GamingSessionEntity(
            packageName = packageName,
            appName = appName,
            startTime = startTime,
            endTime = startTime + (durationSeconds * 1000),
            durationSeconds = durationSeconds,
            avgFps = avgFps,
            avgPing = avgPing,
            maxTemp = maxTemp,
            batteryDrainPercent = batteryDrain
        )
        sessionDao.insertSession(session)
        gameDao.updatePlayTime(packageName, System.currentTimeMillis(), durationSeconds)
    }

    fun launchGame(packageName: String): Boolean {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            true
        } else {
            false
        }
    }
}
