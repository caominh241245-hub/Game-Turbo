package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.example.data.local.GameTurboDatabase
import com.example.data.repository.CleanerRepository
import com.example.data.repository.DeviceStatsRepository
import com.example.data.repository.GameRepository
import com.example.data.repository.VpnRepository

class GameTurboApp : Application() {

    lateinit var database: GameTurboDatabase
        private set

    lateinit var statsRepository: DeviceStatsRepository
        private set

    lateinit var vpnRepository: VpnRepository
        private set

    lateinit var cleanerRepository: CleanerRepository
        private set

    lateinit var gameRepository: GameRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = GameTurboDatabase.getDatabase(this)
        statsRepository = DeviceStatsRepository(this)
        vpnRepository = VpnRepository(this)
        cleanerRepository = CleanerRepository(this)
        gameRepository = GameRepository(
            context = this,
            gameDao = database.gameDao(),
            profileDao = database.gameProfileDao(),
            sessionDao = database.gamingSessionDao()
        )

        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_OVERLAY_ID,
                "Game Turbo Overlay Bar",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Hiển thị thanh công cụ nổi Game Turbo trong trò chơi"
                setShowBadge(false)
            }

            val vpnChannel = NotificationChannel(
                CHANNEL_VPN_ID,
                "Game Turbo VPN Speed Booster",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Duy trì kết nối mạng tăng tốc giảm ping khi chơi game"
                setShowBadge(false)
            }

            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
            notificationManager.createNotificationChannel(vpnChannel)
        }
    }

    companion object {
        const val CHANNEL_OVERLAY_ID = "game_turbo_overlay_channel"
        const val CHANNEL_VPN_ID = "game_turbo_vpn_channel"

        lateinit var instance: GameTurboApp
            private set
    }
}
