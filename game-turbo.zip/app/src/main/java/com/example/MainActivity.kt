package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.BoostAnimationOverlay
import com.example.ui.components.GlassCard
import com.example.ui.screens.CleanerScreen
import com.example.ui.screens.DiagnosticsScreen
import com.example.ui.screens.GameProfileScreen
import com.example.ui.screens.GamesListScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.NetworkBoostScreen
import com.example.ui.screens.PerformanceScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StatisticsScreen
import com.example.ui.screens.TouchOptimizationScreen
import com.example.ui.theme.GameTurboTheme
import com.example.ui.theme.LocalGlassColors
import com.example.ui.theme.NeonCyan
import com.example.ui.viewmodel.GameTurboViewModel
import com.example.ui.viewmodel.TurboNavDestination

class MainActivity : ComponentActivity() {

    private val viewModel: GameTurboViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val uiState by viewModel.uiState.collectAsState()

            GameTurboTheme(darkTheme = uiState.isDarkTheme) {
                MainAppContainer(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppContainer(viewModel: GameTurboViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val glassColors = LocalGlassColors.current

    // Handle back button behavior for sub-screens
    BackHandler(enabled = uiState.currentDestination != TurboNavDestination.HOME) {
        when (uiState.currentDestination) {
            TurboNavDestination.GAME_PROFILE -> viewModel.navigateTo(TurboNavDestination.GAMES_LIBRARY)
            TurboNavDestination.DIAGNOSTICS -> viewModel.navigateTo(TurboNavDestination.SETTINGS)
            else -> viewModel.navigateTo(TurboNavDestination.HOME)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = glassColors.background,
        bottomBar = {
            if (!uiState.isBoosting) {
                GlassBottomNavigationBar(
                    currentDestination = uiState.currentDestination,
                    isVietnamese = uiState.isVietnamese,
                    onNavigate = { destination -> viewModel.navigateTo(destination) }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (uiState.currentDestination) {
                TurboNavDestination.HOME -> HomeScreen(viewModel = viewModel)
                TurboNavDestination.GAMES_LIBRARY -> GamesListScreen(viewModel = viewModel)
                TurboNavDestination.GAME_PROFILE -> GameProfileScreen(viewModel = viewModel)
                TurboNavDestination.PERFORMANCE -> PerformanceScreen(viewModel = viewModel)
                TurboNavDestination.NETWORK_VPN -> NetworkBoostScreen(viewModel = viewModel)
                TurboNavDestination.CLEANER -> CleanerScreen(viewModel = viewModel)
                TurboNavDestination.TOUCH_OPTIMIZER -> TouchOptimizationScreen(viewModel = viewModel)
                TurboNavDestination.STATISTICS -> StatisticsScreen(viewModel = viewModel)
                TurboNavDestination.SETTINGS -> SettingsScreen(viewModel = viewModel)
                TurboNavDestination.DIAGNOSTICS -> DiagnosticsScreen(viewModel = viewModel)
            }

            // Turbo Launch / Boost Animation
            BoostAnimationOverlay(
                isBoosting = uiState.isBoosting,
                gameName = uiState.boostingGameName,
                onBoostComplete = { viewModel.onBoostAnimationComplete() }
            )
        }
    }
}

@Composable
fun GlassBottomNavigationBar(
    currentDestination: TurboNavDestination,
    isVietnamese: Boolean,
    onNavigate: (TurboNavDestination) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(26.dp),
            borderColor = Color(0x44FFFFFF),
            backgroundColor = Color(0xF2080808)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                NavTabItem(
                    title = if (isVietnamese) "Turbo" else "Turbo",
                    icon = Icons.Default.Bolt,
                    isSelected = currentDestination == TurboNavDestination.HOME,
                    onClick = { onNavigate(TurboNavDestination.HOME) }
                )

                NavTabItem(
                    title = if (isVietnamese) "Trò chơi" else "Games",
                    icon = Icons.Default.Gamepad,
                    isSelected = currentDestination == TurboNavDestination.GAMES_LIBRARY || currentDestination == TurboNavDestination.GAME_PROFILE,
                    onClick = { onNavigate(TurboNavDestination.GAMES_LIBRARY) }
                )

                NavTabItem(
                    title = if (isVietnamese) "120 FPS" else "120 FPS",
                    icon = Icons.Default.Speed,
                    isSelected = currentDestination == TurboNavDestination.PERFORMANCE,
                    onClick = { onNavigate(TurboNavDestination.PERFORMANCE) }
                )

                NavTabItem(
                    title = if (isVietnamese) "Mạng" else "Network",
                    icon = Icons.Default.NetworkCheck,
                    isSelected = currentDestination == TurboNavDestination.NETWORK_VPN,
                    onClick = { onNavigate(TurboNavDestination.NETWORK_VPN) }
                )

                NavTabItem(
                    title = if (isVietnamese) "Dọn dẹp" else "Clean",
                    icon = Icons.Default.CleaningServices,
                    isSelected = currentDestination == TurboNavDestination.CLEANER,
                    onClick = { onNavigate(TurboNavDestination.CLEANER) }
                )

                NavTabItem(
                    title = if (isVietnamese) "Cài đặt" else "Settings",
                    icon = Icons.Default.Settings,
                    isSelected = currentDestination == TurboNavDestination.SETTINGS || currentDestination == TurboNavDestination.DIAGNOSTICS,
                    onClick = { onNavigate(TurboNavDestination.SETTINGS) }
                )
            }
        }
    }
}

@Composable
private fun NavTabItem(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(if (isSelected) Color(0x33FFFFFF) else Color.Transparent),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (isSelected) Color.White else Color(0x88FFFFFF),
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = title,
            fontSize = 10.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) Color.White else Color(0x88FFFFFF)
        )
    }
}
