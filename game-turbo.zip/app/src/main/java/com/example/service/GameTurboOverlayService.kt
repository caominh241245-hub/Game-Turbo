package com.example.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.example.GameTurboApp
import com.example.MainActivity
import com.example.data.model.PerformanceMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs

class GameTurboOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var floatingHandleView: View? = null
    private var floatingExpandedHudView: View? = null
    private var isExpanded = false

    private val serviceScope = CoroutineScope(Dispatchers.Main)
    private var statsJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startForeground(1001, createOverlayNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (Settings.canDrawOverlays(this)) {
            showFloatingHandle()
        }
        return START_STICKY
    }

    private fun showFloatingHandle() {
        if (floatingHandleView != null) return

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            },
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 400
        }

        val handleContainer = FrameLayout(this).apply {
            setPadding(12, 16, 16, 16)
            setBackgroundColor(0x00000000)
        }

        // Monochrome Game Turbo floating pill handle
        val handlePill = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(14, 28, 14, 28)
            background = createGlassHandleDrawable()
            elevation = 12f
        }

        val iconView = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_media_play)
            setColorFilter(0xFFFFFFFF.toInt())
            layoutParams = LinearLayout.LayoutParams(36, 36)
        }

        val textLabel = TextView(this).apply {
            text = "TURBO"
            textSize = 9f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 6, 0, 0)
        }

        handlePill.addView(iconView)
        handlePill.addView(textLabel)
        handleContainer.addView(handlePill)

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false

        handleContainer.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - initialTouchX
                    val dy = event.rawY - initialTouchY
                    if (abs(dx) > 10 || abs(dy) > 10) {
                        isDragging = true
                        params.x = (initialX + dx).toInt()
                        params.y = (initialY + dy).toInt()
                        try {
                            windowManager?.updateViewLayout(handleContainer, params)
                        } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        toggleExpandedHud()
                    }
                    true
                }
                else -> false
            }
        }

        floatingHandleView = handleContainer
        try {
            windowManager?.addView(handleContainer, params)
        } catch (_: Exception) {}
    }

    private fun toggleExpandedHud() {
        if (isExpanded) {
            collapseHud()
        } else {
            expandHud()
        }
    }

    private fun expandHud() {
        if (floatingExpandedHudView != null) return
        isExpanded = true

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            },
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 60
        }

        val hudContainer = FrameLayout(this).apply {
            setPadding(24, 16, 24, 16)
        }

        val glassPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 24, 32, 24)
            background = createGlassExpandedDrawable()
            elevation = 20f
        }

        // Header with metrics
        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val titleView = TextView(this).apply {
            text = "⚡ GAME TURBO HUD"
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val closeBtn = TextView(this).apply {
            text = "✕ Đóng"
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(16, 8, 16, 8)
            setOnClickListener { collapseHud() }
        }

        headerRow.addView(titleView)
        headerRow.addView(closeBtn)
        glassPanel.addView(headerRow)

        // Metrics Bar (FPS, Ping, CPU, RAM, Temp - all monochrome white)
        val metricsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 20)
        }

        val fpsText = createMetricPill("FPS", "120")
        val pingText = createMetricPill("PING", "18ms")
        val cpuText = createMetricPill("CPU", "28%")
        val ramText = createMetricPill("RAM", "54%")
        val tempText = createMetricPill("TEMP", "36°C")

        metricsRow.addView(fpsText)
        metricsRow.addView(pingText)
        metricsRow.addView(cpuText)
        metricsRow.addView(ramText)
        metricsRow.addView(tempText)
        glassPanel.addView(metricsRow)

        // Quick Actions Row (White buttons with black text)
        val actionsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 0)
        }

        val boostAction = createActionButton("🚀 Tăng tốc RAM") {
            serviceScope.launch {
                val freed = GameTurboApp.instance.statsRepository.performQuickBoost()
                Toast.makeText(applicationContext, "Đã giải phóng ${freed}MB RAM & Tối ưu GPU!", Toast.LENGTH_SHORT).show()
            }
        }

        val modeAction = createActionButton("⚡ Hiệu năng") {
            GameTurboApp.instance.statsRepository.setPerformanceMode(PerformanceMode.PERFORMANCE)
            Toast.makeText(applicationContext, "Chế độ Hiệu năng cao kích hoạt!", Toast.LENGTH_SHORT).show()
        }

        val dndAction = createActionButton("🔕 Chặn TB") {
            Toast.makeText(applicationContext, "Đã kích hoạt chế độ chặn thông báo khi chơi game", Toast.LENGTH_SHORT).show()
        }

        actionsRow.addView(boostAction)
        actionsRow.addView(modeAction)
        actionsRow.addView(dndAction)
        glassPanel.addView(actionsRow)

        hudContainer.addView(glassPanel)
        floatingExpandedHudView = hudContainer

        try {
            windowManager?.addView(hudContainer, params)
            startHudLiveUpdates(fpsText, pingText, cpuText, ramText, tempText)
        } catch (_: Exception) {}
    }

    private fun startHudLiveUpdates(
        fpsView: View,
        pingView: View,
        cpuView: View,
        ramView: View,
        tempView: View
    ) {
        statsJob?.cancel()
        statsJob = serviceScope.launch {
            while (isActive && isExpanded) {
                val stats = GameTurboApp.instance.statsRepository.statsFlow.value
                (fpsView.findViewById<TextView>(1001))?.text = "${stats.currentFps}"
                (pingView.findViewById<TextView>(1001))?.text = "${stats.pingMs}ms"
                (cpuView.findViewById<TextView>(1001))?.text = "${stats.cpuUsagePercent}%"
                (ramView.findViewById<TextView>(1001))?.text = "${stats.ramUsagePercent}%"
                (tempView.findViewById<TextView>(1001))?.text = "${stats.batteryTempCelsius.toInt()}°C"
                delay(1000)
            }
        }
    }

    private fun createMetricPill(title: String, initialValue: String): View {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(18, 12, 18, 12)
            background = createMetricPillDrawable()
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(6, 0, 6, 0)
            }
        }

        val valText = TextView(this).apply {
            id = 1001
            text = initialValue
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }

        val lblText = TextView(this).apply {
            text = title
            textSize = 10f
            setTextColor(0xCCFFFFFF.toInt())
            gravity = Gravity.CENTER
        }

        container.addView(valText)
        container.addView(lblText)
        return container
    }

    private fun createActionButton(label: String, onClick: () -> Unit): View {
        return TextView(this).apply {
            text = label
            textSize = 12f
            setTextColor(0xFF000000.toInt())
            setPadding(20, 16, 20, 16)
            background = createButtonDrawable()
            gravity = Gravity.CENTER
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(6, 0, 6, 0)
            }
        }
    }

    private fun collapseHud() {
        isExpanded = false
        statsJob?.cancel()
        if (floatingExpandedHudView != null) {
            try {
                windowManager?.removeView(floatingExpandedHudView)
            } catch (_: Exception) {}
            floatingExpandedHudView = null
        }
    }

    private fun createGlassHandleDrawable(): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = 32f
            setColor(0xF0000000.toInt())
            setStroke(2, 0xFFFFFFFF.toInt())
        }
    }

    private fun createGlassExpandedDrawable(): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = 28f
            setColor(0xF80A0A0A.toInt())
            setStroke(2, 0x66FFFFFF.toInt())
        }
    }

    private fun createMetricPillDrawable(): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = 18f
            setColor(0xFF141414.toInt())
            setStroke(1, 0x44FFFFFF.toInt())
        }
    }

    private fun createButtonDrawable(): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = 20f
            setColor(0xFFFFFFFF.toInt())
            setStroke(1, 0xFFFFFFFF.toInt())
        }
    }

    private fun createOverlayNotification(): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, GameTurboOverlayService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, GameTurboApp.CHANNEL_OVERLAY_ID)
            .setContentTitle("Game Turbo Đang Hoạt Động")
            .setContentText("Thanh công cụ nổi hiển thị trên màn hình chơi game")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Tắt thanh nổi", stopPending)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        collapseHud()
        if (floatingHandleView != null) {
            try {
                windowManager?.removeView(floatingHandleView)
            } catch (_: Exception) {}
            floatingHandleView = null
        }
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.example.START_OVERLAY"
        const val ACTION_STOP = "com.example.STOP_OVERLAY"

        fun start(context: Context) {
            val intent = Intent(context, GameTurboOverlayService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, GameTurboOverlayService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
