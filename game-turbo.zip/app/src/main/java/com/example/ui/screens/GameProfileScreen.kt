package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.ViewSidebar
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.GameProfileEntity
import com.example.ui.components.GlassCard
import com.example.ui.theme.ElectricAmber
import com.example.ui.theme.EmeraldNitro
import com.example.ui.theme.LocalGlassColors
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.PurpleCyber
import com.example.ui.viewmodel.GameTurboViewModel
import com.example.ui.viewmodel.TurboNavDestination

@Composable
fun GameProfileScreen(viewModel: GameTurboViewModel) {
    val profile by viewModel.currentEditingProfile.collectAsState()
    val uiState by viewModel.uiState.collectAsState()
    val glassColors = LocalGlassColors.current
    val context = LocalContext.current

    if (profile == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(glassColors.background),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = if (uiState.isVietnamese) "Chưa chọn cấu hình game" else "No game profile selected",
                color = Color.White
            )
        }
        return
    }

    val currentProfile = profile!!
    var mode by remember(currentProfile) { mutableStateOf(currentProfile.performanceMode) }
    var refreshRate by remember(currentProfile) { mutableIntStateOf(currentProfile.targetRefreshRate) }
    var dndEnabled by remember(currentProfile) { mutableStateOf(currentProfile.dndEnabled) }
    var touchOpt by remember(currentProfile) { mutableStateOf(currentProfile.touchOptimization) }
    var floatingBar by remember(currentProfile) { mutableStateOf(currentProfile.floatingBarEnabled) }
    var cleanRam by remember(currentProfile) { mutableStateOf(currentProfile.cleanRamOnLaunch) }
    var networkBoost by remember(currentProfile) { mutableStateOf(currentProfile.networkBoostEnabled) }
    var autoVpnCountry by remember(currentProfile) { mutableStateOf(currentProfile.autoVpnCountry) }
    var brightnessPercent by remember(currentProfile) { mutableFloatStateOf(currentProfile.brightnessPercent.toFloat()) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(glassColors.background)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            // Top Bar
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { viewModel.navigateTo(TurboNavDestination.HOME) }) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "Quay lại",
                                tint = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Column {
                            Text(
                                text = if (uiState.isVietnamese) "HỒ SƠ GAME TURBO" else "GAME PROFILE",
                                style = MaterialTheme.typography.titleLarge,
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = currentProfile.packageName,
                                style = MaterialTheme.typography.bodyMedium,
                                color = glassColors.textSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Button(
                        onClick = {
                            val updated = currentProfile.copy(
                                performanceMode = mode,
                                targetRefreshRate = refreshRate,
                                dndEnabled = dndEnabled,
                                touchOptimization = touchOpt,
                                floatingBarEnabled = floatingBar,
                                cleanRamOnLaunch = cleanRam,
                                networkBoostEnabled = networkBoost,
                                autoVpnCountry = autoVpnCountry,
                                brightnessPercent = brightnessPercent.toInt()
                            )
                            viewModel.saveGameProfile(updated)
                            Toast.makeText(context, if (uiState.isVietnamese) "Đã lưu hồ sơ tùy chỉnh!" else "Profile saved!", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (uiState.isVietnamese) "Lưu" else "Save",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Section: Performance Mode
            item {
                SectionHeader(title = if (uiState.isVietnamese) "CHẾ ĐỘ HIỆU NĂNG" else "PERFORMANCE MODE")
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        ProfileModeSelector(
                            selectedMode = mode,
                            isVietnamese = uiState.isVietnamese,
                            onSelectMode = { mode = it }
                        )
                    }
                }
            }

            // Section: Refresh Rate 120 FPS
            item {
                SectionHeader(title = if (uiState.isVietnamese) "TẦN SỐ QUÉT MÀN HÌNH (FPS)" else "REFRESH RATE (FPS)")
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(60, 90, 120, 144).forEach { hz ->
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { refreshRate = hz },
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (refreshRate == hz) Color.White else Color(0xFF141414),
                                    border = if (refreshRate == hz) null else androidx.compose.foundation.BorderStroke(1.dp, Color(0x33FFFFFF))
                                ) {
                                    Column(
                                        modifier = Modifier.padding(vertical = 10.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = "$hz Hz",
                                            color = if (refreshRate == hz) Color.Black else Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = if (hz >= 120) "Ultra" else if (hz == 90) "Smooth" else "Standard",
                                            color = if (refreshRate == hz) Color.Black else Color(0x88FFFFFF),
                                            fontSize = 9.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Section: Gaming Features Toggles
            item {
                SectionHeader(title = if (uiState.isVietnamese) "TÍNH NĂNG GAME TURBO TỰ ĐỘNG" else "AUTOMATIC TURBO FEATURES")
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ProfileSwitchRow(
                            icon = Icons.Default.ViewSidebar,
                            title = if (uiState.isVietnamese) "Thanh công cụ nổi Game Turbo" else "Floating In-Game HUD Bar",
                            subtitle = if (uiState.isVietnamese) "Hiển thị nút trượt vuốt từ mép màn hình" else "Show edge floating overlay toolbar",
                            checked = floatingBar,
                            onCheckedChange = { floatingBar = it }
                        )

                        ProfileSwitchRow(
                            icon = Icons.Default.NotificationsOff,
                            title = if (uiState.isVietnamese) "Không làm phiền khi chơi (DND)" else "Gaming Do Not Disturb",
                            subtitle = if (uiState.isVietnamese) "Chặn cuộc gọi nổi và thông báo rác" else "Block floating alerts and incoming notifications",
                            checked = dndEnabled,
                            onCheckedChange = { dndEnabled = it }
                        )

                        ProfileSwitchRow(
                            icon = Icons.Default.CleaningServices,
                            title = if (uiState.isVietnamese) "Dọn dẹp RAM trước khi vào game" else "Clean RAM before game launch",
                            subtitle = if (uiState.isVietnamese) "Giải phóng bộ nhớ đệm tự động" else "Auto memory flush on startup",
                            checked = cleanRam,
                            onCheckedChange = { cleanRam = it }
                        )

                        ProfileSwitchRow(
                            icon = Icons.Default.TouchApp,
                            title = if (uiState.isVietnamese) "Tối ưu hóa phản hồi cảm ứng" else "Touch Response Optimization",
                            subtitle = if (uiState.isVietnamese) "Chống chạm nhầm viền & tăng nhạy" else "Anti accidental touch & latency shield",
                            checked = touchOpt,
                            onCheckedChange = { touchOpt = it }
                        )

                        ProfileSwitchRow(
                            icon = Icons.Default.VpnKey,
                            title = if (uiState.isVietnamese) "Tự động kích hoạt VPN Giảm Ping" else "Auto Gaming VPN Speed Boost",
                            subtitle = if (uiState.isVietnamese) "Kết nối máy chủ: $autoVpnCountry" else "Routing server: $autoVpnCountry",
                            checked = networkBoost,
                            onCheckedChange = { networkBoost = it }
                        )
                    }
                }
            }

            // Section: Brightness Lock
            item {
                SectionHeader(title = if (uiState.isVietnamese) "KHÓA ĐỘ SÁNG KHI VÀO GAME" else "BRIGHTNESS LOCK")
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.BrightnessMedium,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (uiState.isVietnamese) "Mức độ sáng cố định" else "Fixed Brightness Level",
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Text(
                                text = "${brightnessPercent.toInt()}%",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        Slider(
                            value = brightnessPercent,
                            onValueChange = { brightnessPercent = it },
                            valueRange = 10f..100f,
                            colors = SliderDefaults.colors(
                                thumbColor = Color.White,
                                activeTrackColor = Color.White,
                                inactiveTrackColor = Color(0x33FFFFFF)
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    val glassColors = LocalGlassColors.current
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        color = glassColors.textSecondary,
        fontSize = 11.sp,
        modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 6.dp)
    )
}

@Composable
private fun ProfileModeSelector(
    selectedMode: String,
    isVietnamese: Boolean,
    onSelectMode: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        ModeOptionCard(
            title = if (isVietnamese) "⚡ Hiệu năng cao (Performance)" else "⚡ High Performance",
            description = if (isVietnamese) "Tối đa khung hình 120 FPS, giải phóng toàn bộ RAM, ưu tiên CPU cao nhất" else "Max frame rates, all RAM freed, top CPU priority",
            isSelected = selectedMode == "PERFORMANCE",
            onClick = { onSelectMode("PERFORMANCE") }
        )
        ModeOptionCard(
            title = if (isVietnamese) "⚖️ Cân bằng (Balanced)" else "⚖️ Balanced Mode",
            description = if (isVietnamese) "Chơi game 90 FPS mượt mà và duy trì thời lượng pin tốt" else "Smooth 90 FPS gaming with balanced battery life",
            isSelected = selectedMode == "BALANCED",
            onClick = { onSelectMode("BALANCED") }
        )
        ModeOptionCard(
            title = if (isVietnamese) "🔋 Tiết kiệm pin (Battery Saver)" else "🔋 Battery Saver Mode",
            description = if (isVietnamese) "Giảm tải hoạt động ngầm, giữ mát máy và tiết kiệm tối đa pin" else "Reduce background workload, cool down device, save battery",
            isSelected = selectedMode == "BATTERY_SAVER",
            onClick = { onSelectMode("BATTERY_SAVER") }
        )
    }
}

@Composable
private fun ModeOptionCard(
    title: String,
    description: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        color = if (isSelected) Color.White else Color(0xFF141414),
        border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, Color(0x33FFFFFF))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = title,
                color = if (isSelected) Color.Black else Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = description,
                color = if (isSelected) Color(0xCC000000) else Color(0xCCFFFFFF),
                fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun ProfileSwitchRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF181818)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (checked) Color.White else Color(0x66FFFFFF),
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = subtitle,
                    color = Color(0xCCFFFFFF),
                    fontSize = 10.sp
                )
            }
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = Color.White,
                uncheckedThumbColor = Color.White,
                uncheckedTrackColor = Color(0x33FFFFFF)
            )
        )
    }
}
