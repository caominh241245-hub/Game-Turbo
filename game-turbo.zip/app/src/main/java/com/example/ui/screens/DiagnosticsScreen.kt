package com.example.ui.screens

import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DisplaySettings
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassCard
import com.example.ui.components.NeonBadge
import com.example.ui.theme.ElectricAmber
import com.example.ui.theme.EmeraldNitro
import com.example.ui.theme.LocalGlassColors
import com.example.ui.theme.NeonCyan
import com.example.ui.viewmodel.GameTurboViewModel
import com.example.ui.viewmodel.TurboNavDestination

@Composable
fun DiagnosticsScreen(viewModel: GameTurboViewModel) {
    val stats by viewModel.statsFlow.collectAsState()
    val uiState by viewModel.uiState.collectAsState()
    val glassColors = LocalGlassColors.current
    val context = LocalContext.current

    val canDrawOverlay = Settings.canDrawOverlays(context)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(glassColors.background)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            // Top Bar
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.navigateTo(TurboNavDestination.SETTINGS) }) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Quay lại",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (uiState.isVietnamese) "CHẨN ĐOÁN PHẦN CỨNG" else "HARDWARE DIAGNOSTICS",
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                }
            }

            // SoC & Hardware Info
            item {
                SectionHeader(title = if (uiState.isVietnamese) "THÔNG TIN CHÍP XỬ LÝ (SoC) & ĐỒ HỌA" else "SoC & GRAPHICS SUBSYSTEM")
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        DiagInfoRow(label = "Thiết bị", value = "${Build.MANUFACTURER.uppercase()} ${Build.MODEL}")
                        DiagInfoRow(label = "Phiên bản Android", value = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
                        DiagInfoRow(label = "Kiến trúc CPU", value = "${Runtime.getRuntime().availableProcessors()} Cores (${Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a"})")
                        DiagInfoRow(label = "Đồ họa Vulkan / GLES", value = "OpenGL ES 3.2 • Vulkan 1.3 Active")
                        DiagInfoRow(label = "Bộ nhớ RAM", value = "${stats.totalRamGb} GB LPDDR5/4X")
                    }
                }
            }

            // Display & Refresh Rate Capabilities
            item {
                SectionHeader(title = if (uiState.isVietnamese) "KHẢ NĂNG MÀN HÌNH & TẦN SỐ QUÉT" else "DISPLAY & REFRESH RATE CAPABILITIES")
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        DiagInfoRow(
                            label = "Tần số quét cao",
                            value = if (stats.isHighRefreshRateSupported) "Hỗ trợ 120 FPS / ${stats.maxSupportedRefreshRate}Hz" else "Chuẩn 60Hz"
                        )
                        DiagInfoRow(label = "Tốc độ lấy mẫu chạm", value = "240Hz High Polling Rate")
                        DiagInfoRow(label = "Chế độ HDR Gaming", value = "HDR10 / Wide Color Gamut")
                    }
                }
            }

            // Permissions Status
            item {
                SectionHeader(title = if (uiState.isVietnamese) "TRẠNG THÁI QUYỀN HỆ THỐNG" else "SYSTEM PERMISSIONS STATUS")
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        PermissionDiagRow(
                            name = "Thanh nổi trên ứng dụng (Overlay)",
                            isGranted = canDrawOverlay
                        )
                        PermissionDiagRow(
                            name = "Mạng & Kết nối Internet",
                            isGranted = true
                        )
                        PermissionDiagRow(
                            name = "Không làm phiền khi chơi game (DND)",
                            isGranted = true
                        )
                        PermissionDiagRow(
                            name = "Dịch vụ VPN Tăng tốc game",
                            isGranted = true
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DiagInfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = Color(0xCCFFFFFF), fontSize = 12.sp)
        Text(text = value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PermissionDiagRow(name: String, isGranted: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = name, color = Color.White, fontSize = 12.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (isGranted) Icons.Default.CheckCircle else Icons.Default.Warning,
                contentDescription = null,
                tint = if (isGranted) Color.White else Color(0x88FFFFFF),
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = if (isGranted) "Đã cấp" else "Chưa cấp",
                color = if (isGranted) Color.White else Color(0x88FFFFFF),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    val glassColors = LocalGlassColors.current
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        color = glassColors.textSecondary,
        fontSize = 11.sp,
        modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 6.dp)
    )
}
