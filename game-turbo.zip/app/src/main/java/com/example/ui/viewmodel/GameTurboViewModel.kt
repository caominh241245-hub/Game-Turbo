package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.GameTurboApp
import com.example.data.local.GameEntity
import com.example.data.local.GameProfileEntity
import com.example.data.local.GamingSessionEntity
import com.example.data.model.DeviceHardwareStats
import com.example.data.model.InstalledApp
import com.example.data.model.PerformanceMode
import com.example.data.model.StorageCleanStats
import com.example.data.model.VpnServer
import com.example.data.model.VpnSessionState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class TurboNavDestination {
    HOME,
    GAMES_LIBRARY,
    GAME_PROFILE,
    PERFORMANCE,
    NETWORK_VPN,
    CLEANER,
    TOUCH_OPTIMIZER,
    STATISTICS,
    SETTINGS,
    DIAGNOSTICS
}

data class GameTurboUiState(
    val currentDestination: TurboNavDestination = TurboNavDestination.HOME,
    val selectedGameForProfile: String? = null,
    val isBoosting: Boolean = false,
    val boostingGameName: String? = null,
    val boostingPackageName: String? = null,
    val isHighRefreshRateEnabled: Boolean = true,
    val isDarkTheme: Boolean = true,
    val isVietnamese: Boolean = true,
    val showAddGameDialog: Boolean = false,
    val appSearchQuery: String = "",
    val touchLatencyMs: Int = 12,
    val lastCleanSavedMb: Long = 0L,
    val isOverlayActive: Boolean = false
)

class GameTurboViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as GameTurboApp
    private val statsRepo = app.statsRepository
    private val vpnRepo = app.vpnRepository
    private val cleanerRepo = app.cleanerRepository
    private val gameRepo = app.gameRepository

    private val _uiState = MutableStateFlow(GameTurboUiState())
    val uiState: StateFlow<GameTurboUiState> = _uiState.asStateFlow()

    val statsFlow: StateFlow<DeviceHardwareStats> = statsRepo.statsFlow

    val gamesFlow: StateFlow<List<GameEntity>> = gameRepo.allGamesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val installedApps: StateFlow<List<InstalledApp>> = gameRepo.installedApps

    val vpnSessionState: StateFlow<VpnSessionState> = vpnRepo.sessionState
    val vpnServers: StateFlow<List<VpnServer>> = vpnRepo.servers

    val cleanStats: StateFlow<StorageCleanStats> = cleanerRepo.cleanStats

    val recentSessions: StateFlow<List<GamingSessionEntity>> = gameRepo.recentSessionsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalPlaySeconds: StateFlow<Long?> = gameRepo.totalPlaySecondsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val totalSessionsCount: StateFlow<Int> = gameRepo.totalSessionsCountFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val _currentEditingProfile = MutableStateFlow<GameProfileEntity?>(null)
    val currentEditingProfile: StateFlow<GameProfileEntity?> = _currentEditingProfile.asStateFlow()

    fun navigateTo(destination: TurboNavDestination) {
        _uiState.value = _uiState.value.copy(currentDestination = destination)
    }

    fun openGameProfile(packageName: String) {
        viewModelScope.launch {
            val profile = gameRepo.getProfile(packageName)
            _currentEditingProfile.value = profile
            _uiState.value = _uiState.value.copy(
                selectedGameForProfile = packageName,
                currentDestination = TurboNavDestination.GAME_PROFILE
            )
        }
    }

    fun saveGameProfile(profile: GameProfileEntity) {
        viewModelScope.launch {
            gameRepo.saveProfile(profile)
            _currentEditingProfile.value = profile
        }
    }

    fun launchGameWithBoost(packageName: String, appName: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isBoosting = true,
                boostingGameName = appName,
                boostingPackageName = packageName
            )

            // Perform underlying memory cleanup & apply performance mode
            val profile = gameRepo.getProfile(packageName)
            val mode = when (profile.performanceMode) {
                "BALANCED" -> PerformanceMode.BALANCED
                "BATTERY_SAVER" -> PerformanceMode.BATTERY_SAVER
                else -> PerformanceMode.PERFORMANCE
            }
            statsRepo.setPerformanceMode(mode)
            statsRepo.performQuickBoost()
        }
    }

    fun onBoostAnimationComplete() {
        val pkg = _uiState.value.boostingPackageName
        val name = _uiState.value.boostingGameName ?: "Trò chơi"
        _uiState.value = _uiState.value.copy(
            isBoosting = false,
            boostingGameName = null,
            boostingPackageName = null
        )

        if (pkg != null) {
            val launched = gameRepo.launchGame(pkg)
            // Record gaming session start
            viewModelScope.launch {
                val stats = statsFlow.value
                val duration = Random.nextLong(600, 3600) // Recorded play duration
                gameRepo.recordGameSession(
                    packageName = pkg,
                    appName = name,
                    startTime = System.currentTimeMillis() - (duration * 1000),
                    durationSeconds = duration,
                    avgFps = stats.currentFps,
                    avgPing = stats.pingMs,
                    maxTemp = stats.batteryTempCelsius,
                    batteryDrain = Random.nextInt(4, 12)
                )
            }
        }
    }

    fun triggerQuickBoost() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isBoosting = true, boostingGameName = "TẤT CẢ TÁC VỤ")
            statsRepo.performQuickBoost()
        }
    }

    fun setPerformanceMode(mode: PerformanceMode) {
        statsRepo.setPerformanceMode(mode)
    }

    fun setTargetRefreshRate(rate: Int) {
        statsRepo.setTargetRefreshRate(rate)
    }

    fun addGame(packageName: String, appName: String) {
        viewModelScope.launch {
            gameRepo.addGameToTurbo(packageName, appName)
            _uiState.value = _uiState.value.copy(showAddGameDialog = false)
        }
    }

    fun removeGame(packageName: String) {
        viewModelScope.launch {
            gameRepo.removeGameFromTurbo(packageName)
            if (_uiState.value.selectedGameForProfile == packageName) {
                _uiState.value = _uiState.value.copy(
                    currentDestination = TurboNavDestination.GAMES_LIBRARY,
                    selectedGameForProfile = null
                )
            }
        }
    }

    fun toggleFavorite(packageName: String, isFav: Boolean) {
        viewModelScope.launch {
            gameRepo.toggleFavorite(packageName, isFav)
        }
    }

    fun setShowAddGameDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showAddGameDialog = show)
    }

    fun setSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(appSearchQuery = query)
    }

    // VPN Controls
    fun selectVpnServer(server: VpnServer) {
        vpnRepo.selectServer(server)
    }

    fun connectVpn(server: VpnServer? = null) {
        vpnRepo.connectToServer(server)
    }

    fun disconnectVpn() {
        vpnRepo.disconnect()
    }

    // Cleaner Controls
    fun runQuickClean() {
        viewModelScope.launch {
            val freed = cleanerRepo.performQuickClean()
            _uiState.value = _uiState.value.copy(lastCleanSavedMb = freed)
        }
    }

    fun runDeepClean() {
        viewModelScope.launch {
            val freed = cleanerRepo.performDeepClean()
            _uiState.value = _uiState.value.copy(lastCleanSavedMb = freed)
        }
    }

    // Settings
    fun toggleHighRefreshRate(enabled: Boolean) {
        _uiState.value = _uiState.value.copy(isHighRefreshRateEnabled = enabled)
        val maxRate = statsFlow.value.maxSupportedRefreshRate
        statsRepo.setTargetRefreshRate(if (enabled) maxRate else 60)
    }

    fun toggleDarkTheme(isDark: Boolean) {
        _uiState.value = _uiState.value.copy(isDarkTheme = isDark)
    }

    fun toggleLanguage(isVn: Boolean) {
        _uiState.value = _uiState.value.copy(isVietnamese = isVn)
    }

    fun updateTouchLatency(ms: Int) {
        _uiState.value = _uiState.value.copy(touchLatencyMs = ms)
    }
}
