package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.GamingSessionEntity
import com.example.ui.components.GlassCard
import com.example.ui.components.NeonBadge
import com.example.ui.theme.ElectricAmber
import com.example.ui.theme.EmeraldNitro
import com.example.ui.theme.LocalGlassColors
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.PurpleCyber
import com.example.ui.viewmodel.GameTurboViewModel
import com.example.ui.viewmodel.TurboNavDestination
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun StatisticsScreen(viewModel: GameTurboViewModel) {
    val totalPlaySeconds by viewModel.totalPlaySeconds.collectAsState()
    val totalSessions by viewModel.totalSessionsCount.collectAsState()
    val recentSessions by viewModel.recentSessions.collectAsState()
    val uiState by viewModel.uiState.collectAsState()
    val glassColors = LocalGlassColors.current

    val totalHours = ((totalPlaySeconds ?: 0L) / 3600f)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(glassColors.background)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            // Top Bar
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.navigateTo(TurboNavDestination.HOME) }) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Quay lại",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (uiState.isVietnamese) "THỐNG KÊ TRẬN ĐẤU" else "GAMING STATS & HISTORY",
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                }
            }

            // Summary Totals Card
            item {
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = if (uiState.isVietnamese) "TỔNG QUAN THỜI GIAN CHƠI" else "GAMING TIME OVERVIEW",
                            style = MaterialTheme.typography.labelLarge,
                            color = glassColors.textSecondary,
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            StatSummaryPill(
                                title = if (uiState.isVietnamese) "TỔNG GIỜ CHƠI" else "TOTAL HOURS",
                                value = String.format("%.1f h", totalHours),
                                icon = Icons.Default.Timer,
                                color = NeonCyan,
                                modifier = Modifier.weight(1f)
                            )
                            StatSummaryPill(
                                title = if (uiState.isVietnamese) "SỐ TRẬN ĐÃ CHƠI" else "TOTAL SESSIONS",
                                value = "$totalSessions",
                                icon = Icons.Default.Gamepad,
                                color = ElectricAmber,
                                modifier = Modifier.weight(1f)
                            )
                            StatSummaryPill(
                                title = if (uiState.isVietnamese) "FPS TRUNG BÌNH" else "AVG FPS",
                                value = "118",
                                icon = Icons.Default.Speed,
                                color = EmeraldNitro,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Weekly Gaming Time Bars
            item {
                SectionHeader(title = if (uiState.isVietnamese) "THỜI LƯỢNG CHƠI TRONG TUẦN (GIỜ)" else "WEEKLY GAMING BREAKDOWN (HOURS)")
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            val days = listOf("T2", "T3", "T4", "T5", "T6", "T7", "CN")
                            val hours = listOf(1.5f, 2.8f, 0.8f, 3.2f, 4.5f, 5.8f, 4.2f)

                            days.zip(hours).forEach { (day, h) ->
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Bottom,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(
                                        text = "${h}h",
                                        fontSize = 9.sp,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Box(
                                        modifier = Modifier
                                            .width(16.dp)
                                            .height((h * 14).dp.coerceIn(12.dp, 80.dp))
                                            .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                            .background(if (h > 4f) Color.White else Color(0x88FFFFFF))
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(text = day, fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // Recent Gaming Sessions History
            item {
                SectionHeader(title = if (uiState.isVietnamese) "LỊCH SỬ TRẬN ĐẤU GẦN ĐÂY" else "RECENT SESSIONS HISTORY")
            }

            if (recentSessions.isEmpty()) {
                item {
                    Text(
                        text = if (uiState.isVietnamese) "Chưa có dữ liệu trận đấu. Hãy khởi chạy game từ Game Turbo để ghi nhận!" else "No session data. Launch a game via Game Turbo to record!",
                        color = Color(0x88FFFFFF),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)
                    )
                }
            } else {
                items(recentSessions, key = { it.id }) { session ->
                    SessionItemRow(session = session, isVietnamese = uiState.isVietnamese)
                }
            }
        }
    }
}

@Composable
private fun StatSummaryPill(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = Color(0xFF141414),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x33FFFFFF))
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Black)
            Text(text = title, color = Color(0xCCFFFFFF), fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun SessionItemRow(
    session: GamingSessionEntity,
    isVietnamese: Boolean
) {
    val glassColors = LocalGlassColors.current
    val dateStr = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(session.startTime))

    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF181818)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.Gamepad, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(text = session.appName, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = "$dateStr • ${session.durationSeconds / 60} phút",
                        color = Color(0xCCFFFFFF),
                        fontSize = 11.sp
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(text = "${session.avgFps} FPS", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(text = "Ping: ${session.avgPing}ms • ${session.maxTemp.toInt()}°C", color = Color(0xCCFFFFFF), fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    val glassColors = LocalGlassColors.current
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        color = glassColors.textSecondary,
        fontSize = 11.sp,
        modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 6.dp)
    )
}
