package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DeviceHardwareStats
import com.example.data.model.PerformanceMode
import com.example.service.GameTurboOverlayService
import kotlin.math.roundToInt

@Composable
fun FloatingBarHudPreview(
    stats: DeviceHardwareStats,
    onQuickBoost: () -> Unit,
    onSetMode: (PerformanceMode) -> Unit,
    onNavigateToNetwork: () -> Unit,
    onNavigateToTouch: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var isExpanded by remember { mutableStateOf(false) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(200f) }
    var brightnessLevel by remember { mutableFloatStateOf(0.85f) }
    var dndActive by remember { mutableStateOf(true) }

    Box(modifier = modifier) {
        // Floating Draggable Pill Handle (Pure Black & White)
        Box(
            modifier = Modifier
                .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        offsetX = (offsetX + dragAmount.x).coerceIn(0f, 300f)
                        offsetY = (offsetY + dragAmount.y).coerceIn(100f, 1600f)
                    }
                }
                .clip(RoundedCornerShape(30.dp))
                .background(Color(0xF0000000))
                .border(
                    width = 1.5.dp,
                    color = Color.White,
                    shape = RoundedCornerShape(30.dp)
                )
                .clickable { isExpanded = !isExpanded }
                .padding(horizontal = 12.dp, vertical = 14.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.Bolt,
                    contentDescription = "Mở thanh Game Turbo",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "TURBO",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )
            }
        }

        // Expanded Glassmorphism Game Turbo HUD Toolbar (Monochrome Black & White)
        AnimatedVisibility(
            visible = isExpanded,
            enter = fadeIn() + slideInVertically { -it / 2 },
            exit = fadeOut() + slideOutVertically { -it / 2 },
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 16.dp, start = 12.dp, end = 12.dp)
        ) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                color = Color(0xF80A0A0A),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0x66FFFFFF)),
                shadowElevation = 24.dp
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // HUD Top Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "XIAOMI GAME TURBO 5.0",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // System Overlay Activator Button (White button, black text)
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color.White,
                                modifier = Modifier.clickable {
                                    if (Settings.canDrawOverlays(context)) {
                                        GameTurboOverlayService.start(context)
                                        Toast.makeText(context, "Đã bật Thanh Nổi hệ thống ngoài màn hình!", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "Cần cấp quyền 'Hiển thị trên ứng dụng khác'", Toast.LENGTH_LONG).show()
                                        val intent = Intent(
                                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                            Uri.parse("package:${context.packageName}")
                                        )
                                        context.startActivity(intent)
                                    }
                                }
                            ) {
                                Text(
                                    text = "⚡ Bật ngoài Game",
                                    color = Color.Black,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(Color(0x33FFFFFF))
                                    .clickable { isExpanded = false },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Đóng",
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Live Hardware Metrics Strip
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        HudMetricPill(
                            title = "FPS",
                            value = "${stats.currentFps}",
                            modifier = Modifier.weight(1f)
                        )
                        HudMetricPill(
                            title = "PING",
                            value = "${stats.pingMs}ms",
                            modifier = Modifier.weight(1f)
                        )
                        HudMetricPill(
                            title = "CPU",
                            value = "${stats.cpuUsagePercent}%",
                            modifier = Modifier.weight(1f)
                        )
                        HudMetricPill(
                            title = "GPU",
                            value = "${stats.gpuUsagePercent}%",
                            modifier = Modifier.weight(1f)
                        )
                        HudMetricPill(
                            title = "RAM",
                            value = "${stats.ramUsagePercent}%",
                            modifier = Modifier.weight(1f)
                        )
                        HudMetricPill(
                            title = "NHIỆT",
                            value = "${stats.batteryTempCelsius.toInt()}°C",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Performance Mode Switcher (Monochrome: White for selected, dark for unselected)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF141414))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        ModeTab(
                            title = "⚡ Hiệu năng",
                            isSelected = stats.activePerformanceMode == PerformanceMode.PERFORMANCE,
                            modifier = Modifier.weight(1f),
                            onClick = { onSetMode(PerformanceMode.PERFORMANCE) }
                        )
                        ModeTab(
                            title = "⚖️ Cân bằng",
                            isSelected = stats.activePerformanceMode == PerformanceMode.BALANCED,
                            modifier = Modifier.weight(1f),
                            onClick = { onSetMode(PerformanceMode.BALANCED) }
                        )
                        ModeTab(
                            title = "🔋 Tiết kiệm",
                            isSelected = stats.activePerformanceMode == PerformanceMode.BATTERY_SAVER,
                            modifier = Modifier.weight(1f),
                            onClick = { onSetMode(PerformanceMode.BATTERY_SAVER) }
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Quick Action Tools Grid (White icons, white text, white borders)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        HudToolAction(
                            icon = Icons.Default.Bolt,
                            label = "Tăng tốc RAM",
                            onClick = {
                                onQuickBoost()
                                Toast.makeText(context, "🚀 Đã giải phóng RAM và tối ưu đồ họa GPU!", Toast.LENGTH_SHORT).show()
                            }
                        )
                        HudToolAction(
                            icon = Icons.Default.CameraAlt,
                            label = "Chụp màn hình",
                            onClick = {
                                Toast.makeText(context, "📸 Đã chụp ảnh màn hình trận đấu!", Toast.LENGTH_SHORT).show()
                            }
                        )
                        HudToolAction(
                            icon = Icons.Default.Videocam,
                            label = "Quay 120 FPS",
                            onClick = {
                                Toast.makeText(context, "🎥 Đã bắt đầu ghi hình gameplay chất lượng cao!", Toast.LENGTH_SHORT).show()
                            }
                        )
                        HudToolAction(
                            icon = Icons.Default.NotificationsOff,
                            label = if (dndActive) "Chặn TB: Bật" else "Chặn TB: Tắt",
                            onClick = {
                                dndActive = !dndActive
                                Toast.makeText(context, if (dndActive) "🔕 Đã chặn thông báo rác" else "🔔 Cho phép thông báo", Toast.LENGTH_SHORT).show()
                            }
                        )
                        HudToolAction(
                            icon = Icons.Default.VpnKey,
                            label = "VPN Giảm Ping",
                            onClick = onNavigateToNetwork
                        )
                        HudToolAction(
                            icon = Icons.Default.TouchApp,
                            label = "Tối ưu cảm ứng",
                            onClick = onNavigateToTouch
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Brightness slider (Monochrome White slider)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.BrightnessMedium,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Độ sáng: ${(brightnessLevel * 100).toInt()}%",
                            fontSize = 11.sp,
                            color = Color(0xCCFFFFFF),
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Slider(
                            value = brightnessLevel,
                            onValueChange = { brightnessLevel = it },
                            colors = SliderDefaults.colors(
                                thumbColor = Color.White,
                                activeTrackColor = Color.White,
                                inactiveTrackColor = Color(0x33FFFFFF)
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HudMetricPill(
    title: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF141414),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x33FFFFFF))
    ) {
        Column(
            modifier = Modifier.padding(vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Black
            )
            Text(
                text = title,
                color = Color(0xCCFFFFFF),
                fontSize = 9.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun ModeTab(
    title: String,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(10.dp),
        color = if (isSelected) Color.White else Color.Transparent,
        border = if (!isSelected) androidx.compose.foundation.BorderStroke(1.dp, Color(0x22FFFFFF)) else null
    ) {
        Text(
            text = title,
            color = if (isSelected) Color.Black else Color.White,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.padding(vertical = 6.dp)
        )
    }
}

@Composable
private fun HudToolAction(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(Color(0xFF181818))
                .border(1.dp, Color(0x66FFFFFF), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 9.sp,
            color = Color.White,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}
