package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DisplaySettings
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DeviceHardwareStats
import com.example.data.model.PerformanceMode
import com.example.data.model.ThermalStatus
import com.example.ui.components.CircularMetricGauge
import com.example.ui.components.GlassCard
import com.example.ui.components.NeonBadge
import com.example.ui.theme.ElectricAmber
import com.example.ui.theme.EmeraldNitro
import com.example.ui.theme.LocalGlassColors
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.PurpleCyber
import com.example.ui.viewmodel.GameTurboViewModel
import com.example.ui.viewmodel.TurboNavDestination

@Composable
fun PerformanceScreen(viewModel: GameTurboViewModel) {
    val stats by viewModel.statsFlow.collectAsState()
    val uiState by viewModel.uiState.collectAsState()
    val glassColors = LocalGlassColors.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(glassColors.background)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            // Top Bar
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.navigateTo(TurboNavDestination.HOME) }) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Quay lại",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (uiState.isVietnamese) "HIỆU NĂNG & 120 FPS" else "PERFORMANCE & 120 FPS",
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                }
            }

            // Realtime Performance Gauges
            item {
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (uiState.isVietnamese) "TRẠNG THÁI HIỆN TẠI" else "CURRENT ACTIVE STATE",
                                style = MaterialTheme.typography.labelLarge,
                                color = glassColors.textSecondary,
                                fontSize = 11.sp
                            )
                            NeonBadge(
                                text = if (uiState.isVietnamese) stats.activePerformanceMode.displayNameVn else stats.activePerformanceMode.displayNameEn,
                                color = when (stats.activePerformanceMode) {
                                    PerformanceMode.PERFORMANCE -> NeonCyan
                                    PerformanceMode.BALANCED -> EmeraldNitro
                                    PerformanceMode.BATTERY_SAVER -> ElectricAmber
                                }
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            CircularMetricGauge(
                                value = stats.currentFps.toFloat(),
                                maxValue = 144f,
                                title = "FPS",
                                unitText = "Hz",
                                accentColor = EmeraldNitro,
                                size = 76.dp
                            )
                            CircularMetricGauge(
                                value = stats.cpuUsagePercent.toFloat(),
                                maxValue = 100f,
                                title = "CPU",
                                unitText = "%",
                                accentColor = ElectricAmber,
                                size = 76.dp
                            )
                            CircularMetricGauge(
                                value = stats.gpuUsagePercent.toFloat(),
                                maxValue = 100f,
                                title = "GPU Turbo",
                                unitText = "%",
                                accentColor = PurpleCyber,
                                size = 76.dp
                            )
                            CircularMetricGauge(
                                value = stats.ramUsagePercent.toFloat(),
                                maxValue = 100f,
                                title = "RAM",
                                unitText = "${stats.ramUsagePercent}%",
                                accentColor = NeonCyan,
                                size = 76.dp
                            )
                        }
                    }
                }
            }

            // Section 1: 120 FPS High Refresh Rate Engine
            item {
                SectionHeader(title = if (uiState.isVietnamese) "CÔNG NGHỆ 120 FPS / TẦN SỐ QUÉT CAO" else "120 FPS HIGH REFRESH RATE ENGINE")
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(CircleShape)
                                        .background(EmeraldNitro.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DisplaySettings,
                                        contentDescription = null,
                                        tint = EmeraldNitro,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = if (uiState.isVietnamese) "Chế độ 120 FPS / Siêu Mượt" else "120 FPS / Ultra Smooth Mode",
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = if (stats.isHighRefreshRateSupported)
                                            (if (uiState.isVietnamese) "Phần cứng màn hình hỗ trợ tối đa ${stats.maxSupportedRefreshRate}Hz" else "Display hardware supports up to ${stats.maxSupportedRefreshRate}Hz")
                                        else
                                            (if (uiState.isVietnamese) "Màn hình thiết bị chuẩn 60Hz" else "Standard 60Hz display"),
                                        color = if (stats.isHighRefreshRateSupported) EmeraldNitro else Color(0xFF90A4AE),
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            Switch(
                                checked = uiState.isHighRefreshRateEnabled,
                                onCheckedChange = { viewModel.toggleHighRefreshRate(it) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.Black,
                                    checkedTrackColor = Color.White,
                                    uncheckedThumbColor = Color.White,
                                    uncheckedTrackColor = Color(0x33FFFFFF)
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Supported Refresh Rates Pills
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            RefreshRatePill("60 Hz", isSupported = true, isSelected = stats.targetRefreshRate == 60, onClick = { viewModel.setTargetRefreshRate(60) }, modifier = Modifier.weight(1f))
                            RefreshRatePill("90 Hz", isSupported = stats.maxSupportedRefreshRate >= 90, isSelected = stats.targetRefreshRate == 90, onClick = { viewModel.setTargetRefreshRate(90) }, modifier = Modifier.weight(1f))
                            RefreshRatePill("120 Hz", isSupported = stats.maxSupportedRefreshRate >= 120, isSelected = stats.targetRefreshRate == 120, onClick = { viewModel.setTargetRefreshRate(120) }, modifier = Modifier.weight(1f))
                            RefreshRatePill("144 Hz", isSupported = stats.maxSupportedRefreshRate >= 144, isSelected = stats.targetRefreshRate == 144, onClick = { viewModel.setTargetRefreshRate(144) }, modifier = Modifier.weight(1f))
                        }
                    }
                }
            }

            // Section 2: Performance Mode Selectors
            item {
                SectionHeader(title = if (uiState.isVietnamese) "LỰA CHỌN CHẾ ĐỘ HOẠT ĐỘNG" else "PERFORMANCE PROFILES")
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PerformanceModeCard(
                        title = if (uiState.isVietnamese) "⚡ Chế độ Hiệu năng cao (Performance)" else "⚡ High Performance Mode",
                        description = if (uiState.isVietnamese) "Ưu tiên tối đa phần cứng, giải phóng RAM, mở khóa 120 FPS và mạng không độ trễ." else "Prioritize hardware speed, flush background RAM, unlock 120 FPS.",
                        isSelected = stats.activePerformanceMode == PerformanceMode.PERFORMANCE,
                        accentColor = NeonCyan,
                        onClick = { viewModel.setPerformanceMode(PerformanceMode.PERFORMANCE) }
                    )

                    PerformanceModeCard(
                        title = if (uiState.isVietnamese) "⚖️ Chế độ Cân bằng (Balanced)" else "⚖️ Balanced Mode",
                        description = if (uiState.isVietnamese) "Duy trì 90 FPS mượt mà, tối ưu hóa năng lượng để máy không bị nóng." else "Maintain smooth 90 FPS, optimize power efficiency and thermals.",
                        isSelected = stats.activePerformanceMode == PerformanceMode.BALANCED,
                        accentColor = EmeraldNitro,
                        onClick = { viewModel.setPerformanceMode(PerformanceMode.BALANCED) }
                    )

                    PerformanceModeCard(
                        title = if (uiState.isVietnamese) "🔋 Chế độ Tiết kiệm pin (Battery Saver)" else "🔋 Battery Saver Mode",
                        description = if (uiState.isVietnamese) "Giới hạn 60Hz, hạ nhiệt độ tức thì, kéo dài thêm 2-3 giờ chơi game liên tục." else "Limit to 60Hz, cool down device, extend gaming battery life.",
                        isSelected = stats.activePerformanceMode == PerformanceMode.BATTERY_SAVER,
                        accentColor = ElectricAmber,
                        onClick = { viewModel.setPerformanceMode(PerformanceMode.BATTERY_SAVER) }
                    )
                }
            }

            // Section 3: Thermal Protection HUD
            item {
                SectionHeader(title = if (uiState.isVietnamese) "BẢO VỆ NHIỆT ĐỘ & PIN THÔNG MINH" else "SMART THERMAL & BATTERY PROTECTION")
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(Color(stats.thermalStatus.colorHex).copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Thermostat,
                                        contentDescription = null,
                                        tint = Color(stats.thermalStatus.colorHex),
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "${stats.batteryTempCelsius.toInt()}°C • ${if (uiState.isVietnamese) stats.thermalStatus.titleVn else stats.thermalStatus.titleEn}",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = if (uiState.isVietnamese) "Bảo vệ phần cứng tự động luôn bật" else "Hardware thermal protection active",
                                        color = glassColors.textSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.BatteryChargingFull,
                                    contentDescription = null,
                                    tint = EmeraldNitro,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${stats.batteryPercent}%",
                                    color = EmeraldNitro,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RefreshRatePill(
    label: String,
    isSupported: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.clickable(enabled = isSupported) { onClick() },
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) Color.White else if (isSupported) Color(0xFF141414) else Color(0xFF0A0A0A),
        border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, Color(0x33FFFFFF))
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = label,
                color = if (isSelected) Color.Black else if (isSupported) Color.White else Color(0x66FFFFFF),
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
            Text(
                text = if (isSupported) "Hỗ trợ" else "Không hỗ trợ",
                color = if (isSelected) Color.Black else Color(0x88FFFFFF),
                fontSize = 9.sp
            )
        }
    }
}

@Composable
private fun PerformanceModeCard(
    title: String,
    description: String,
    isSelected: Boolean,
    accentColor: Color,
    onClick: () -> Unit
) {
    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        borderColor = if (isSelected) accentColor else null,
        glowColor = if (isSelected) accentColor else null,
        onClick = onClick
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    color = if (isSelected) accentColor else Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                if (isSelected) {
                    NeonBadge(text = "ĐANG CHỌN", color = accentColor)
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = description,
                color = Color(0xFF90A4AE),
                fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    val glassColors = LocalGlassColors.current
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        color = glassColors.textSecondary,
        fontSize = 11.sp,
        modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 6.dp)
    )
}
