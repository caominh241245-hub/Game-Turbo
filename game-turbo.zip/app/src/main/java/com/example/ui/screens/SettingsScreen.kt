package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DisplaySettings
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.ViewSidebar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.GameTurboOverlayService
import com.example.ui.components.GlassCard
import com.example.ui.components.NeonBadge
import com.example.ui.theme.ElectricAmber
import com.example.ui.theme.EmeraldNitro
import com.example.ui.theme.LocalGlassColors
import com.example.ui.theme.NeonCyan
import com.example.ui.viewmodel.GameTurboViewModel
import com.example.ui.viewmodel.TurboNavDestination

@Composable
fun SettingsScreen(viewModel: GameTurboViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val stats by viewModel.statsFlow.collectAsState()
    val glassColors = LocalGlassColors.current
    val context = LocalContext.current

    var autoTurbo by remember { mutableStateOf(true) }
    var fpsMonitor by remember { mutableStateOf(true) }
    var tempWarning by remember { mutableStateOf(true) }
    var checkingUpdate by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(glassColors.background)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            // Top Bar
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.navigateTo(TurboNavDestination.HOME) }) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Quay lại",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (uiState.isVietnamese) "CÀI ĐẶT HỆ THỐNG" else "TURBO SETTINGS",
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                }
            }

            // General & Interface Settings
            item {
                SectionHeader(title = if (uiState.isVietnamese) "GIAO DIỆN & NGÔN NGỮ" else "INTERFACE & LANGUAGE")
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        // Language Switcher
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(NeonCyan.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(imageVector = Icons.Default.Language, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(20.dp))
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(text = if (uiState.isVietnamese) "Ngôn ngữ ứng dụng" else "Language", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Text(text = if (uiState.isVietnamese) "Tiếng Việt (Mặc định) / English" else "Vietnamese / English", color = Color(0xFF90A4AE), fontSize = 10.sp)
                                }
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Surface(
                                    modifier = Modifier.clickable { viewModel.toggleLanguage(true) },
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (uiState.isVietnamese) NeonCyan else Color(0x22FFFFFF)
                                ) {
                                    Text(text = "VN", color = if (uiState.isVietnamese) Color.Black else Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                                }
                                Surface(
                                    modifier = Modifier.clickable { viewModel.toggleLanguage(false) },
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (!uiState.isVietnamese) NeonCyan else Color(0x22FFFFFF)
                                ) {
                                    Text(text = "EN", color = if (!uiState.isVietnamese) Color.Black else Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                                }
                            }
                        }

                        // Theme Mode
                        SettingSwitchRow(
                            icon = Icons.Default.DarkMode,
                            title = if (uiState.isVietnamese) "Chế độ Gaming Kính Tối (Obsidian)" else "Dark Obsidian Gaming Theme",
                            subtitle = if (uiState.isVietnamese) "Giao diện kính lỏng neon tương phản cao" else "High contrast liquid-glass dark mode",
                            checked = uiState.isDarkTheme,
                            onCheckedChange = { viewModel.toggleDarkTheme(it) }
                        )
                    }
                }
            }

            // In-Game Floating Bar & Overlay Settings
            item {
                SectionHeader(title = if (uiState.isVietnamese) "THANH CÔNG CỤ NỔI KHI CHƠI GAME" else "IN-GAME FLOATING OVERLAY BAR")
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(ElectricAmber.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(imageVector = Icons.Default.ViewSidebar, contentDescription = null, tint = ElectricAmber, modifier = Modifier.size(20.dp))
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = if (uiState.isVietnamese) "Kích hoạt Thanh Nổi ngoài game" else "Enable In-Game Overlay HUD",
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = if (uiState.isVietnamese) "Hiển thị nút trượt vuốt từ mép màn hình" else "Floating draggable handle on screen edge",
                                        color = Color(0xFF90A4AE),
                                        fontSize = 10.sp
                                    )
                                }
                            }

                            Button(
                                onClick = {
                                    if (Settings.canDrawOverlays(context)) {
                                        GameTurboOverlayService.start(context)
                                        Toast.makeText(context, if (uiState.isVietnamese) "Đã khởi chạy thanh công cụ nổi ngoài màn hình!" else "Overlay Bar service started!", Toast.LENGTH_SHORT).show()
                                    } else {
                                        val intent = Intent(
                                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                            Uri.parse("package:${context.packageName}")
                                        )
                                        context.startActivity(intent)
                                        Toast.makeText(context, if (uiState.isVietnamese) "Vui lòng cấp quyền 'Hiển thị trên ứng dụng khác'" else "Please allow overlay permission", Toast.LENGTH_LONG).show()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = if (uiState.isVietnamese) "Bật ngay" else "Enable",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        SettingSwitchRow(
                            icon = Icons.Default.Bolt,
                            title = if (uiState.isVietnamese) "Tự động kích hoạt khi mở game" else "Auto-activate on game launch",
                            subtitle = if (uiState.isVietnamese) "Tự dọn RAM và bật Game Turbo khi mở game" else "Auto-boost and launch HUD on games",
                            checked = autoTurbo,
                            onCheckedChange = { autoTurbo = it }
                        )

                        SettingSwitchRow(
                            icon = Icons.Default.Speed,
                            title = if (uiState.isVietnamese) "Giám sát FPS & Tần số quét" else "FPS & Refresh Rate Monitor",
                            subtitle = if (uiState.isVietnamese) "Đo tốc độ khung hình và tần số hiển thị" else "Real-time frame intervals & hz meter",
                            checked = fpsMonitor,
                            onCheckedChange = { fpsMonitor = it }
                        )

                        SettingSwitchRow(
                            icon = Icons.Default.HealthAndSafety,
                            title = if (uiState.isVietnamese) "Cảnh báo quá nhiệt thông minh" else "Smart Overheat Warning",
                            subtitle = if (uiState.isVietnamese) "Nhắc nhở giảm đồ họa khi máy vượt quá 45°C" else "Alert when device temperature exceeds 45°C",
                            checked = tempWarning,
                            onCheckedChange = { tempWarning = it }
                        )
                    }
                }
            }

            // System Diagnostics & Updates
            item {
                SectionHeader(title = if (uiState.isVietnamese) "HỆ THỐNG & CHẨN ĐOÁN" else "SYSTEM & DIAGNOSTICS")
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SettingActionRow(
                            icon = Icons.Default.Tune,
                            title = if (uiState.isVietnamese) "Chẩn đoán phần cứng & Cảm biến" else "Hardware & Sensor Diagnostics",
                            subtitle = if (uiState.isVietnamese) "Kiểm tra SoC, OpenGL, Vulkan, Màn hình" else "Inspect SoC, OpenGL, Vulkan, Display",
                            color = Color.White,
                            onClick = { viewModel.navigateTo(TurboNavDestination.DIAGNOSTICS) }
                        )

                        SettingActionRow(
                            icon = Icons.Default.SystemUpdate,
                            title = if (uiState.isVietnamese) "Kiểm tra bản cập nhật máy chủ" else "Check Server Updates",
                            subtitle = if (checkingUpdate) (if (uiState.isVietnamese) "Đang kiểm tra máy chủ..." else "Checking server...") else (if (uiState.isVietnamese) "Phiên bản v5.2.0 • Đã cập nhật mới nhất" else "Version v5.2.0 • Latest release"),
                            color = Color.White,
                            onClick = {
                                checkingUpdate = true
                                Toast.makeText(context, if (uiState.isVietnamese) "Bạn đang sử dụng Game Turbo phiên bản mới nhất (v5.2.0)!" else "You are using the latest version (v5.2.0)!", Toast.LENGTH_SHORT).show()
                                checkingUpdate = false
                            }
                        )

                        SettingActionRow(
                            icon = Icons.Default.Info,
                            title = if (uiState.isVietnamese) "Về Xiaomi Game Turbo 5.0" else "About Xiaomi Game Turbo 5.0",
                            subtitle = if (uiState.isVietnamese) "Ứng dụng tăng tốc game chuẩn Android 10+" else "High-performance gaming booster for Android 10+",
                            color = Color.White,
                            onClick = {
                                Toast.makeText(context, "Xiaomi Game Turbo 5.0 Liquid Glass Edition", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingSwitchRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF181818)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = if (checked) Color.White else Color(0x66FFFFFF), modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(text = subtitle, color = Color(0xCCFFFFFF), fontSize = 10.sp)
            }
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = Color.White,
                uncheckedThumbColor = Color.White,
                uncheckedTrackColor = Color(0x33FFFFFF)
            )
        )
    }
}

@Composable
private fun SettingActionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    color: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF181818)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(text = subtitle, color = Color(0xCCFFFFFF), fontSize = 10.sp)
            }
        }

        Text(text = "→", color = Color.White, fontSize = 16.sp)
    }
}

@Composable
private fun SectionHeader(title: String) {
    val glassColors = LocalGlassColors.current
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        color = glassColors.textSecondary,
        fontSize = 11.sp,
        modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 6.dp)
    )
}
