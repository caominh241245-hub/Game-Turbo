package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.SdCard
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassCard
import com.example.ui.components.NeonBadge
import com.example.ui.theme.ElectricAmber
import com.example.ui.theme.EmeraldNitro
import com.example.ui.theme.LocalGlassColors
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.PurpleCyber
import com.example.ui.viewmodel.GameTurboViewModel
import com.example.ui.viewmodel.TurboNavDestination

@Composable
fun CleanerScreen(viewModel: GameTurboViewModel) {
    val stats by viewModel.statsFlow.collectAsState()
    val cleanStats by viewModel.cleanStats.collectAsState()
    val uiState by viewModel.uiState.collectAsState()
    val glassColors = LocalGlassColors.current
    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(glassColors.background)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            // Top Bar
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.navigateTo(TurboNavDestination.HOME) }) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Quay lại",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (uiState.isVietnamese) "DỌN DẸP RAM & BỘ NHỚ" else "RAM & STORAGE CLEANER",
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                }
            }

            // RAM & Storage Health Bars Card
            item {
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = if (uiState.isVietnamese) "DUNG LƯỢNG BỘ NHỚ HỆ THỐNG" else "SYSTEM MEMORY USAGE",
                            style = MaterialTheme.typography.labelLarge,
                            color = glassColors.textSecondary,
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // RAM Bar
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.Memory, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(text = "RAM: ${stats.usedRamGb}GB / ${stats.totalRamGb}GB", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Text(text = "${stats.ramUsagePercent}%", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { stats.ramUsagePercent / 100f },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp)),
                                color = Color.White,
                                trackColor = Color(0x33FFFFFF)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Storage Bar
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.SdCard, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(text = "Bộ nhớ trong: ${cleanStats.usedStorageGb}GB / ${cleanStats.totalStorageGb}GB", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Text(
                                    text = "${((cleanStats.usedStorageGb / cleanStats.totalStorageGb) * 100).toInt()}%",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { (cleanStats.usedStorageGb / cleanStats.totalStorageGb).coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp)),
                                color = Color.White,
                                trackColor = Color(0x33FFFFFF)
                            )
                        }
                    }
                }
            }

            // Junk Scan Breakdown Items
            item {
                SectionHeader(title = if (uiState.isVietnamese) "CHI TIẾT DỮ LIỆU CÓ THỂ DỌN AN TOÀN" else "SAFE JUNK BREAKDOWN")
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CleanCategoryCard(
                        icon = Icons.Default.Folder,
                        title = if (uiState.isVietnamese) "Bộ nhớ đệm ứng dụng (Cache)" else "App Cache Files",
                        subtitle = if (uiState.isVietnamese) "Dữ liệu tạm của ứng dụng có thể xóa an toàn" else "Safe temporary cached data",
                        sizeMb = cleanStats.appCacheMb,
                        color = NeonCyan
                    )

                    CleanCategoryCard(
                        icon = Icons.Default.CleaningServices,
                        title = if (uiState.isVietnamese) "Tệp rác & Log hệ thống tạm" else "Temporary & Log Files",
                        subtitle = if (uiState.isVietnamese) "Tệp thừa phát sinh khi chạy phần mềm" else "System logs & temporary artifacts",
                        sizeMb = cleanStats.tempFilesMb,
                        color = ElectricAmber
                    )

                    CleanCategoryCard(
                        icon = Icons.Default.Delete,
                        title = if (uiState.isVietnamese) "Gói cài đặt thừa (APK Residue)" else "Residual APK Packages",
                        subtitle = if (uiState.isVietnamese) "Các gói file cài đặt không còn dùng" else "Old installation package residues",
                        sizeMb = cleanStats.apkResidueMb,
                        color = PurpleCyber
                    )
                }
            }

            // Clean Actions
            item {
                SectionHeader(title = if (uiState.isVietnamese) "CÔNG CỤ DỌN DẸP CHUYÊN DỤNG" else "SPECIALIZED CLEANING ACTIONS")
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CleanActionButton(
                        title = if (uiState.isVietnamese) "🧹 Dọn Dẹp Nhanh (Quick Clean)" else "🧹 Quick Clean",
                        description = if (uiState.isVietnamese) "Xóa bộ nhớ đệm và giải phóng RAM nhanh chóng" else "Clear cache and free RAM in seconds",
                        accentColor = NeonCyan,
                        onClick = {
                            viewModel.runQuickClean()
                            Toast.makeText(context, if (uiState.isVietnamese) "Đã dọn dẹp xong ${cleanStats.appCacheMb}MB rác!" else "Cleaned ${cleanStats.appCacheMb}MB junk!", Toast.LENGTH_SHORT).show()
                        }
                    )

                    CleanActionButton(
                        title = if (uiState.isVietnamese) "🚀 Dọn Dẹp Tăng Tốc Game (Turbo Boost Clean)" else "🚀 Game Boost Deep Clean",
                        description = if (uiState.isVietnamese) "Dọn dẹp sâu toàn bộ RAM & rác trước khi thi đấu esport" else "Deep memory sweep before competitive gaming",
                        accentColor = EmeraldNitro,
                        onClick = {
                            viewModel.runDeepClean()
                            Toast.makeText(context, if (uiState.isVietnamese) "Đã giải phóng tối đa RAM và bộ nhớ đệm!" else "Maximum RAM & Cache boosted!", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun CleanCategoryCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    sizeMb: Long,
    color: Color
) {
    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(text = title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(text = subtitle, color = Color(0xFF90A4AE), fontSize = 10.sp)
                }
            }

            Text(
                text = "${sizeMb} MB",
                color = color,
                fontSize = 14.sp,
                fontWeight = FontWeight.Black
            )
        }
    }
}

@Composable
private fun CleanActionButton(
    title: String,
    description: String,
    accentColor: Color,
    onClick: () -> Unit
) {
    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        borderColor = accentColor.copy(alpha = 0.6f),
        glowColor = accentColor,
        onClick = onClick
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = accentColor,
                    contentColor = Color.Black
                ) {
                    Text(text = "THỰC HIỆN", fontWeight = FontWeight.Black, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = description, color = Color(0xFFB0BEC5), fontSize = 11.sp)
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    val glassColors = LocalGlassColors.current
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        color = glassColors.textSecondary,
        fontSize = 11.sp,
        modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 6.dp)
    )
}
