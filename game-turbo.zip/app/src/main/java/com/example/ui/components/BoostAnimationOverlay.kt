package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun BoostAnimationOverlay(
    isBoosting: Boolean,
    gameName: String? = null,
    onBoostComplete: () -> Unit
) {
    if (!isBoosting) return

    var boostProgress by remember { mutableFloatStateOf(0f) }
    var stepIndex by remember { mutableIntStateOf(0) }

    LaunchedEffect(isBoosting) {
        boostProgress = 0f
        stepIndex = 0

        // Step 1: Clean RAM
        stepIndex = 1
        delay(400)
        boostProgress = 0.25f

        // Step 2: CPU/GPU Turbo Mode
        stepIndex = 2
        delay(450)
        boostProgress = 0.55f

        // Step 3: Refresh Rate 120Hz & DND
        stepIndex = 3
        delay(450)
        boostProgress = 0.85f

        // Step 4: Network boost
        stepIndex = 4
        delay(400)
        boostProgress = 1.0f

        delay(600)
        onBoostComplete()
    }

    val animatedProgress by animateFloatAsState(
        targetValue = boostProgress,
        animationSpec = tween(durationMillis = 350, easing = FastOutSlowInEasing),
        label = "progress"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "rotation")
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "turbine"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.96f))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Turbine Gauge & Center Boost Logo
            Box(
                modifier = Modifier.size(200.dp),
                contentAlignment = Alignment.Center
            ) {
                // Rotating Turbine Rings (Monochrome white)
                Canvas(modifier = Modifier.size(190.dp).rotate(rotationAngle)) {
                    val stroke = 3.dp.toPx()
                    drawArc(
                        color = Color(0x66FFFFFF),
                        startAngle = 0f,
                        sweepAngle = 260f,
                        useCenter = false,
                        style = Stroke(stroke, cap = StrokeCap.Round)
                    )
                }

                // Main Progress Arc (Black & White)
                Canvas(modifier = Modifier.size(170.dp)) {
                    val stroke = 8.dp.toPx()
                    drawArc(
                        color = Color(0x33FFFFFF),
                        startAngle = 120f,
                        sweepAngle = 300f,
                        useCenter = false,
                        style = Stroke(stroke, cap = StrokeCap.Round)
                    )
                    drawArc(
                        color = Color.White,
                        startAngle = 120f,
                        sweepAngle = 300f * animatedProgress,
                        useCenter = false,
                        style = Stroke(stroke, cap = StrokeCap.Round)
                    )
                }

                // Center Icon & Percent
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(44.dp)
                    )
                    Text(
                        text = "${(animatedProgress * 100).toInt()}%",
                        style = MaterialTheme.typography.displayMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "TURBO ENGINE",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xCCFFFFFF),
                        letterSpacing = 2.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            Text(
                text = if (gameName != null) "ĐANG KHỞI CHẠY $gameName" else "GAME TURBO ĐANG TĂNG TỐC",
                style = MaterialTheme.typography.headlineMedium,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Optimization Steps List
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OptimizationStepItem(
                    icon = Icons.Default.CleaningServices,
                    title = "Giải phóng RAM & Dọn rác bộ nhớ",
                    subtitle = "Đã dọn +520MB RAM, CPU sẵn sàng",
                    isActive = stepIndex >= 1,
                    isDone = stepIndex > 1
                )
                OptimizationStepItem(
                    icon = Icons.Default.Speed,
                    title = "Kích hoạt GPU & CPU Max Turbo",
                    subtitle = "Tối ưu hóa luồng phân phối phần cứng",
                    isActive = stepIndex >= 2,
                    isDone = stepIndex > 2
                )
                OptimizationStepItem(
                    icon = Icons.Default.NotificationsOff,
                    title = "Tần số quét 120Hz & Chặn thông báo",
                    subtitle = "Mở khóa màn hình mượt & Không làm phiền",
                    isActive = stepIndex >= 3,
                    isDone = stepIndex > 3
                )
                OptimizationStepItem(
                    icon = Icons.Default.Wifi,
                    title = "Tối ưu hóa đường truyền mạng",
                    subtitle = "Độ trễ thấp, giảm giật ping",
                    isActive = stepIndex >= 4,
                    isDone = animatedProgress >= 1f
                )
            }
        }
    }
}

@Composable
private fun OptimizationStepItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    isActive: Boolean,
    isDone: Boolean
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = if (isActive) Color(0xFF161616) else Color(0xFF0D0D0D),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isDone || isActive) Color(0x66FFFFFF) else Color(0x22FFFFFF)
        )
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(if (isDone || isActive) Color(0x33FFFFFF) else Color(0x11FFFFFF)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isDone) Icons.Default.CheckCircle else icon,
                    contentDescription = null,
                    tint = if (isDone || isActive) Color.White else Color(0x88FFFFFF),
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = if (isActive) Color.White else Color(0x88FFFFFF),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = subtitle,
                    color = if (isDone) Color.White else Color(0xCCFFFFFF),
                    fontSize = 11.sp
                )
            }
        }
    }
}
