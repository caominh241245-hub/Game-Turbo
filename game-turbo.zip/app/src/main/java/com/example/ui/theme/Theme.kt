package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

data class GlassThemeColors(
    val isDark: Boolean,
    val surfaceGlass: Color,
    val borderGlass: Color,
    val borderHighlight: Color,
    val background: Color,
    val cardBackground: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val accentCyan: Color,
    val accentAmber: Color,
    val accentEmerald: Color,
    val accentCrimson: Color
)

val LocalGlassColors = staticCompositionLocalOf {
    GlassThemeColors(
        isDark = true,
        surfaceGlass = GlassSurfaceDark,
        borderGlass = GlassBorderDark,
        borderHighlight = GlassBorderNeon,
        background = MonochromeBackground,
        cardBackground = MonochromeCard,
        textPrimary = TextPrimaryDark,
        textSecondary = TextSecondaryDark,
        textMuted = TextTertiaryDark,
        accentCyan = Color.White,
        accentAmber = Color.White,
        accentEmerald = Color.White,
        accentCrimson = Color.White
    )
}

// Strict Black & White Color Scheme
private val MonochromeColorScheme = darkColorScheme(
    primary = Color.White,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF1E1E1E),
    onPrimaryContainer = Color.White,
    secondary = Color.White,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF1E1E1E),
    onSecondaryContainer = Color.White,
    tertiary = Color.White,
    onTertiary = Color.Black,
    background = MonochromeBackground,
    onBackground = Color.White,
    surface = MonochromeSurface,
    onSurface = Color.White,
    surfaceVariant = MonochromeCard,
    onSurfaceVariant = Color.White,
    error = Color.White,
    onError = Color.Black
)

@Composable
fun GameTurboTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val glassColors = GlassThemeColors(
        isDark = true,
        surfaceGlass = GlassSurfaceDark,
        borderGlass = GlassBorderDark,
        borderHighlight = GlassBorderNeon,
        background = MonochromeBackground,
        cardBackground = MonochromeCard,
        textPrimary = TextPrimaryDark,
        textSecondary = TextSecondaryDark,
        textMuted = TextTertiaryDark,
        accentCyan = Color.White,
        accentAmber = Color.White,
        accentEmerald = Color.White,
        accentCrimson = Color.White
    )

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = Color.Black.toArgb()
            window.navigationBarColor = Color.Black.toArgb()
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = false
                isAppearanceLightNavigationBars = false
            }
        }
    }

    CompositionLocalProvider(LocalGlassColors provides glassColors) {
        MaterialTheme(
            colorScheme = MonochromeColorScheme,
            typography = Typography,
            content = content
        )
    }
}
