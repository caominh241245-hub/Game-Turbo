package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Pure Monochrome Noir Theme: Strictly Black and White only
val MonochromeBackground = Color(0xFF000000)
val MonochromeSurface = Color(0xFF0A0A0A)
val MonochromeCard = Color(0xFF121212)
val MonochromeElevated = Color(0xFF1A1A1A)

val GlassSurfaceDark = Color(0xEE101010)
val GlassSurfaceHighlight = Color(0x22FFFFFF)
val GlassBorderDark = Color(0x33FFFFFF)
val GlassBorderNeon = Color(0x88FFFFFF)

// All Accent Colors mapped strictly to White / Crisp Monochrome
val NeonCyan = Color(0xFFFFFFFF)
val NeonCyanGlow = Color(0x40FFFFFF)
val ElectricAmber = Color(0xFFFFFFFF)
val ElectricAmberGlow = Color(0x40FFFFFF)
val EmeraldNitro = Color(0xFFFFFFFF)
val EmeraldNitroGlow = Color(0x40FFFFFF)
val CrimsonNitro = Color(0xFFFFFFFF)
val CrimsonNitroGlow = Color(0x40FFFFFF)
val PurpleCyber = Color(0xFFFFFFFF)

// Text Colors: Crisp White and Subtle Translucent Whites (no color tints)
val TextPrimaryDark = Color(0xFFFFFFFF)
val TextSecondaryDark = Color(0xCCFFFFFF)
val TextTertiaryDark = Color(0x88FFFFFF)

// Aliases mapped strictly to Black and White
val ObsidianBackground = MonochromeBackground
val ObsidianSurface = MonochromeSurface
val LightBackground = MonochromeBackground
val LightSurface = MonochromeSurface
val GlassSurfaceLight = GlassSurfaceDark
val GlassBorderLight = GlassBorderDark
val TextPrimaryLight = Color(0xFFFFFFFF)
val TextSecondaryLight = Color(0xCCFFFFFF)
val TextTertiaryLight = Color(0x88FFFFFF)
