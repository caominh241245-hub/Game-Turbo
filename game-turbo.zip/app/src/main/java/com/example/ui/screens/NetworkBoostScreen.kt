package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DeviceHardwareStats
import com.example.data.model.VpnServer
import com.example.data.model.VpnSessionState
import com.example.data.model.VpnStatus
import com.example.service.GameTurboVpnService
import com.example.ui.components.GlassCard
import com.example.ui.components.NeonBadge
import com.example.ui.theme.ElectricAmber
import com.example.ui.theme.EmeraldNitro
import com.example.ui.theme.LocalGlassColors
import com.example.ui.theme.NeonCyan
import com.example.ui.viewmodel.GameTurboViewModel
import com.example.ui.viewmodel.TurboNavDestination

@Composable
fun NetworkBoostScreen(viewModel: GameTurboViewModel) {
    val stats by viewModel.statsFlow.collectAsState()
    val vpnSession by viewModel.vpnSessionState.collectAsState()
    val servers by viewModel.vpnServers.collectAsState()
    val uiState by viewModel.uiState.collectAsState()
    val glassColors = LocalGlassColors.current
    val context = LocalContext.current

    val vpnLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val intent = Intent(context, GameTurboVpnService::class.java).apply {
                action = GameTurboVpnService.ACTION_START
                putExtra(GameTurboVpnService.EXTRA_COUNTRY, vpnSession.selectedServer?.countryNameVn ?: "Việt Nam")
                putExtra(GameTurboVpnService.EXTRA_CITY, vpnSession.selectedServer?.cityVn ?: "Hà Nội")
            }
            context.startService(intent)
            viewModel.connectVpn()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(glassColors.background)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            // Top Bar
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.navigateTo(TurboNavDestination.HOME) }) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Quay lại",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (uiState.isVietnamese) "TĂNG TỐC MẠNG & VPN" else "NETWORK BOOST & VPN",
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                }
            }

            // Live Network Metrics Card
            item {
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (uiState.isVietnamese) "CHẤT LƯỢNG KẾT NỐI GAMING" else "GAMING CONNECTION QUALITY",
                                style = MaterialTheme.typography.labelLarge,
                                color = glassColors.textSecondary,
                                fontSize = 11.sp
                            )
                            NeonBadge(
                                text = if (stats.pingMs < 30) "SIÊU MƯỢT (EXCELLENT)" else "BÌNH THƯỜNG",
                                color = if (stats.pingMs < 30) EmeraldNitro else ElectricAmber,
                                icon = Icons.Default.NetworkCheck
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Ping, Jitter, Packet Loss 3-col
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            NetPillItem(title = "PING", value = "${stats.pingMs} ms", color = if (stats.pingMs < 35) EmeraldNitro else ElectricAmber, modifier = Modifier.weight(1f))
                            NetPillItem(title = "JITTER", value = "${stats.jitterMs} ms", color = NeonCyan, modifier = Modifier.weight(1f))
                            NetPillItem(title = "PACKET LOSS", value = "${stats.packetLossPercent}%", color = EmeraldNitro, modifier = Modifier.weight(1f))
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Download & Upload Speeds
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0x33141F2F))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceAround,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.CloudDownload, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "Tải xuống: ${stats.downloadSpeedMbps.toInt()} Mbps", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.CloudUpload, contentDescription = null, tint = ElectricAmber, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "Tải lên: ${stats.uploadSpeedMbps.toInt()} Mbps", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }

            // VPN Status & Connection Toggle
            item {
                SectionHeader(title = if (uiState.isVietnamese) "GAME TURBO VPN GIẢM PING" else "GAME TURBO LOW-LATENCY VPN")
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(20.dp),
                    borderColor = if (vpnSession.status == VpnStatus.CONNECTED) EmeraldNitro else null
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (vpnSession.status == VpnStatus.CONNECTED) EmeraldNitro.copy(alpha = 0.2f) else NeonCyan.copy(alpha = 0.15f)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.VpnKey,
                                        contentDescription = null,
                                        tint = if (vpnSession.status == VpnStatus.CONNECTED) EmeraldNitro else NeonCyan,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = when (vpnSession.status) {
                                            VpnStatus.CONNECTED -> if (uiState.isVietnamese) "Đang kết nối: ${vpnSession.selectedServer?.cityVn}" else "Connected: ${vpnSession.selectedServer?.cityEn}"
                                            VpnStatus.CONNECTING -> if (uiState.isVietnamese) "Đang đàm phán máy chủ..." else "Connecting to node..."
                                            VpnStatus.DISCONNECTING -> if (uiState.isVietnamese) "Đang ngắt kết nối..." else "Disconnecting..."
                                            VpnStatus.DISCONNECTED -> if (uiState.isVietnamese) "Chưa kết nối VPN" else "VPN Disconnected"
                                        },
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = if (vpnSession.status == VpnStatus.CONNECTED)
                                            "${if (uiState.isVietnamese) "Thời gian:" else "Duration:"} ${vpnSession.durationSeconds / 60}m ${vpnSession.durationSeconds % 60}s • Ping: ${vpnSession.currentPingMs}ms"
                                        else
                                            (if (uiState.isVietnamese) "Định tuyến đường truyền tối ưu cho game" else "Optimized gaming low-jitter routing"),
                                        color = if (vpnSession.status == VpnStatus.CONNECTED) EmeraldNitro else glassColors.textSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            Button(
                                onClick = {
                                    if (vpnSession.status == VpnStatus.CONNECTED) {
                                        val stopIntent = Intent(context, GameTurboVpnService::class.java).apply {
                                            action = GameTurboVpnService.ACTION_STOP
                                        }
                                        context.startService(stopIntent)
                                        viewModel.disconnectVpn()
                                    } else {
                                        val vpnPrepareIntent = VpnService.prepare(context)
                                        if (vpnPrepareIntent != null) {
                                            vpnLauncher.launch(vpnPrepareIntent)
                                        } else {
                                            val intent = Intent(context, GameTurboVpnService::class.java).apply {
                                                action = GameTurboVpnService.ACTION_START
                                                putExtra(GameTurboVpnService.EXTRA_COUNTRY, vpnSession.selectedServer?.countryNameVn ?: "Việt Nam")
                                                putExtra(GameTurboVpnService.EXTRA_CITY, vpnSession.selectedServer?.cityVn ?: "Hà Nội")
                                            }
                                            context.startService(intent)
                                            viewModel.connectVpn()
                                        }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color.White,
                                    contentColor = Color.Black
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = if (vpnSession.status == VpnStatus.CONNECTED) (if (uiState.isVietnamese) "Ngắt" else "Disconnect") else (if (uiState.isVietnamese) "Kết nối" else "Connect"),
                                    fontWeight = FontWeight.Black,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }

            // VPN Server List
            item {
                SectionHeader(title = if (uiState.isVietnamese) "DANH SÁCH MÁY CHỦ GAMING (ƯU TIÊN VIỆT NAM)" else "GAMING NODES (VIETNAM PRIORITIZED)")
            }

            items(servers, key = { it.id }) { server ->
                val isSelected = vpnSession.selectedServer?.id == server.id
                VpnServerItemRow(
                    server = server,
                    isSelected = isSelected,
                    isVietnamese = uiState.isVietnamese,
                    onClick = { viewModel.selectVpnServer(server) }
                )
            }
        }
    }
}

@Composable
private fun NetPillItem(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = Color(0x33141E2D),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.3f))
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                color = color,
                fontSize = 14.sp,
                fontWeight = FontWeight.Black
            )
            Text(
                text = title,
                color = Color(0xFF90A4AE),
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun VpnServerItemRow(
    server: VpnServer,
    isSelected: Boolean,
    isVietnamese: Boolean,
    onClick: () -> Unit
) {
    val glassColors = LocalGlassColors.current

    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        shape = RoundedCornerShape(16.dp),
        borderColor = if (isSelected) NeonCyan else null,
        glowColor = if (isSelected) NeonCyan else null,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = server.flagEmoji,
                    fontSize = 24.sp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (isVietnamese) server.countryNameVn else server.countryNameEn,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        if (server.isPrioritized) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(shape = CircleShape, color = Color(0x33FFFFFF)) {
                                Text(
                                    text = if (isVietnamese) "Ưu tiên VN" else "Priority",
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    Text(
                        text = if (isVietnamese) server.cityVn else server.cityEn,
                        color = Color(0xCCFFFFFF),
                        fontSize = 11.sp
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "~${server.basePingMs}ms",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                if (isSelected) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Đã chọn",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    val glassColors = LocalGlassColors.current
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        color = glassColors.textSecondary,
        fontSize = 11.sp,
        modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 6.dp)
    )
}
