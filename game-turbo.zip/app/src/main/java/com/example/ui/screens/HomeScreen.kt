package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.GameEntity
import com.example.data.model.DeviceHardwareStats
import com.example.ui.components.CircularMetricGauge
import com.example.ui.components.FloatingBarHudPreview
import com.example.ui.components.GlassCard
import com.example.ui.components.NeonBadge
import com.example.ui.theme.ElectricAmber
import com.example.ui.theme.EmeraldNitro
import com.example.ui.theme.LocalGlassColors
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.PurpleCyber
import com.example.ui.viewmodel.GameTurboViewModel
import com.example.ui.viewmodel.TurboNavDestination

@Composable
fun HomeScreen(viewModel: GameTurboViewModel) {
    val stats by viewModel.statsFlow.collectAsState()
    val games by viewModel.gamesFlow.collectAsState()
    val uiState by viewModel.uiState.collectAsState()
    val glassColors = LocalGlassColors.current

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(glassColors.background),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            // Header: Game Turbo Brand + Fast Boost Button
            item {
                HomeHeroHeader(
                    stats = stats,
                    isVietnamese = uiState.isVietnamese,
                    onQuickBoost = { viewModel.triggerQuickBoost() }
                )
            }

            // Real-Time Hardware Gauges Strip (CPU, GPU, RAM, Temp, Battery, 120 FPS)
            item {
                HardwareStatsCard(stats = stats, isVietnamese = uiState.isVietnamese)
            }

            // My Games Carousel & Quick Launch
            item {
                GamesSection(
                    games = games,
                    isVietnamese = uiState.isVietnamese,
                    onLaunch = { game -> viewModel.launchGameWithBoost(game.packageName, game.appName) },
                    onProfile = { game -> viewModel.openGameProfile(game.packageName) },
                    onToggleFavorite = { pkg, fav -> viewModel.toggleFavorite(pkg, fav) },
                    onAddGame = { viewModel.setShowAddGameDialog(true) },
                    onViewAll = { viewModel.navigateTo(TurboNavDestination.GAMES_LIBRARY) }
                )
            }

            // Quick Access Feature Hub
            item {
                FeatureHubGrid(
                    isVietnamese = uiState.isVietnamese,
                    onNavigate = { destination -> viewModel.navigateTo(destination) }
                )
            }

            // Device Thermal & Network Quality Indicator
            item {
                ThermalAndNetworkCard(
                    stats = stats,
                    isVietnamese = uiState.isVietnamese,
                    onTestNetwork = { viewModel.navigateTo(TurboNavDestination.NETWORK_VPN) }
                )
            }
        }

        // Floating In-Game Bar HUD Simulator
        FloatingBarHudPreview(
            stats = stats,
            onQuickBoost = { viewModel.triggerQuickBoost() },
            onSetMode = { mode -> viewModel.setPerformanceMode(mode) },
            onNavigateToNetwork = { viewModel.navigateTo(TurboNavDestination.NETWORK_VPN) },
            onNavigateToTouch = { viewModel.navigateTo(TurboNavDestination.TOUCH_OPTIMIZER) },
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
private fun HomeHeroHeader(
    stats: DeviceHardwareStats,
    isVietnamese: Boolean,
    onQuickBoost: () -> Unit
) {
    val glassColors = LocalGlassColors.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "GAME TURBO",
                        style = MaterialTheme.typography.displayMedium.copy(fontSize = 24.sp),
                        color = glassColors.textPrimary,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.5.sp
                    )
                }
                Text(
                    text = if (isVietnamese) "Trình tăng tốc game Xiaomi 5.0" else "Xiaomi Game Turbo 5.0 Booster",
                    style = MaterialTheme.typography.bodyMedium,
                    color = glassColors.textSecondary
                )
            }

            NeonBadge(
                text = if (stats.isHighRefreshRateSupported) "120 FPS READY" else "60 FPS",
                color = if (stats.isHighRefreshRateSupported) EmeraldNitro else NeonCyan,
                icon = Icons.Default.Speed
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Large One-Tap Boost Button
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            backgroundColor = Color(0xFF141414),
            borderColor = Color(0x66FFFFFF),
            onClick = onQuickBoost
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(Color.White),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            tint = Color.Black,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = if (isVietnamese) "TĂNG TỐC TỨC THÌ" else "INSTANT TURBO BOOST",
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = if (isVietnamese) "Giải phóng RAM, tối ưu CPU, mạng & GPU" else "Flush RAM, boost CPU, GPU & network",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xCCFFFFFF)
                        )
                    }
                }

                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(30.dp)
                )
            }
        }
    }
}

@Composable
private fun HardwareStatsCard(
    stats: DeviceHardwareStats,
    isVietnamese: Boolean
) {
    val glassColors = LocalGlassColors.current

    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isVietnamese) "GIÁM SÁT PHẦN CỨNG THỜI GIAN THỰC" else "REAL-TIME HARDWARE HUD",
                        style = MaterialTheme.typography.labelLarge,
                        color = glassColors.textSecondary,
                        fontSize = 11.sp
                    )
                    Text(
                        text = stats.networkType,
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonCyan,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Gauges Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    CircularMetricGauge(
                        value = stats.currentFps.toFloat(),
                        maxValue = 144f,
                        title = "FPS",
                        unitText = "Hz",
                        accentColor = EmeraldNitro,
                        size = 72.dp
                    )
                    CircularMetricGauge(
                        value = stats.cpuUsagePercent.toFloat(),
                        maxValue = 100f,
                        title = "CPU",
                        unitText = "%",
                        accentColor = ElectricAmber,
                        size = 72.dp
                    )
                    CircularMetricGauge(
                        value = stats.gpuUsagePercent.toFloat(),
                        maxValue = 100f,
                        title = "GPU",
                        unitText = "%",
                        accentColor = PurpleCyber,
                        size = 72.dp
                    )
                    CircularMetricGauge(
                        value = stats.ramUsagePercent.toFloat(),
                        maxValue = 100f,
                        title = "RAM",
                        unitText = "${stats.usedRamGb}/${stats.totalRamGb}G",
                        accentColor = NeonCyan,
                        size = 72.dp
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Sub-Metrics Pill Bar (Ping, Temp, Battery)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0x33141E2D))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Wifi,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Ping: ${stats.pingMs}ms",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "🌡️ ${stats.batteryTempCelsius.toInt()}°C (${if (isVietnamese) stats.thermalStatus.titleVn.split(" ")[0] else stats.thermalStatus.titleEn.split(" ")[0]})",
                            color = Color(stats.thermalStatus.colorHex),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "🔋 ${stats.batteryPercent}% ${if (stats.isCharging) "⚡" else ""}",
                            color = EmeraldNitro,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GamesSection(
    games: List<GameEntity>,
    isVietnamese: Boolean,
    onLaunch: (GameEntity) -> Unit,
    onProfile: (GameEntity) -> Unit,
    onToggleFavorite: (String, Boolean) -> Unit,
    onAddGame: () -> Unit,
    onViewAll: () -> Unit
) {
    val glassColors = LocalGlassColors.current

    Column(modifier = Modifier.padding(top = 16.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Gamepad,
                    contentDescription = null,
                    tint = ElectricAmber,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isVietnamese) "TRÒ CHƠI CỦA TÔI" else "MY GAMES",
                    style = MaterialTheme.typography.titleLarge,
                    color = glassColors.textPrimary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(8.dp))
                Surface(
                    shape = CircleShape,
                    color = ElectricAmber.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = "${games.size}",
                        color = ElectricAmber,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Text(
                text = if (isVietnamese) "Xem tất cả →" else "View all →",
                color = NeonCyan,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { onViewAll() }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Games Horizontal Carousel
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(games) { game ->
                GameCardItem(
                    game = game,
                    isVietnamese = isVietnamese,
                    onLaunch = { onLaunch(game) },
                    onProfile = { onProfile(game) },
                    onToggleFavorite = { fav -> onToggleFavorite(game.packageName, fav) }
                )
            }

            // Add Game Card
            item {
                GlassCard(
                    modifier = Modifier
                        .width(150.dp)
                        .height(190.dp),
                    shape = RoundedCornerShape(20.dp),
                    onClick = onAddGame
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(NeonCyan.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Thêm game",
                                tint = NeonCyan,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = if (isVietnamese) "Thêm game" else "Add Game",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isVietnamese) "Cài đặt ứng dụng" else "Installed apps",
                            color = glassColors.textSecondary,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GameCardItem(
    game: GameEntity,
    isVietnamese: Boolean,
    onLaunch: () -> Unit,
    onProfile: () -> Unit,
    onToggleFavorite: (Boolean) -> Unit
) {
    val glassColors = LocalGlassColors.current

    GlassCard(
        modifier = Modifier
            .width(160.dp)
            .height(200.dp),
        shape = RoundedCornerShape(20.dp),
        borderColor = if (game.isFavorite) ElectricAmber.copy(alpha = 0.6f) else null,
        glowColor = if (game.isFavorite) ElectricAmber else null
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header: Favorite Icon + Settings Icon
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (game.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Yêu thích",
                    tint = if (game.isFavorite) ElectricAmber else glassColors.textMuted,
                    modifier = Modifier
                        .size(20.dp)
                        .clickable { onToggleFavorite(!game.isFavorite) }
                )

                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = "Cấu hình profile",
                    tint = NeonCyan,
                    modifier = Modifier
                        .size(20.dp)
                        .clickable { onProfile() }
                )
            }

            // Game Icon & Name
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF181818))
                        .border(1.dp, Color(0x44FFFFFF), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Gamepad,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = game.appName,
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    fontSize = 13.sp
                )

                Text(
                    text = if (game.totalPlayTimeSeconds > 0) "${game.totalPlayTimeSeconds / 60}m ${if (isVietnamese) "đã chơi" else "played"}" else if (isVietnamese) "Sẵn sàng" else "Ready",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xCCFFFFFF)
                )
            }

            // Launch Button
            Button(
                onClick = onLaunch,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(36.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = Color.Black
                ),
                contentPadding = PaddingValues(0.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isVietnamese) "BẬT TURBO" else "LAUNCH",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
    }
}

@Composable
private fun FeatureHubGrid(
    isVietnamese: Boolean,
    onNavigate: (TurboNavDestination) -> Unit
) {
    val glassColors = LocalGlassColors.current

    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 16.dp)) {
        Text(
            text = if (isVietnamese) "BỘ CÔNG CỤ GAME TURBO" else "GAME TURBO TOOLKIT",
            style = MaterialTheme.typography.labelLarge,
            color = glassColors.textSecondary,
            fontSize = 11.sp
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            FeatureTile(
                title = if (isVietnamese) "Chế độ & 120 FPS" else "Modes & 120Hz",
                subtitle = if (isVietnamese) "Hiệu năng / Pin" else "Performance tuning",
                icon = Icons.Default.Speed,
                accentColor = EmeraldNitro,
                modifier = Modifier.weight(1f),
                onClick = { onNavigate(TurboNavDestination.PERFORMANCE) }
            )
            FeatureTile(
                title = if (isVietnamese) "VPN Giảm Ping" else "Gaming VPN",
                subtitle = if (isVietnamese) "12 Máy chủ gaming" else "Latency optimizer",
                icon = Icons.Default.VpnKey,
                accentColor = NeonCyan,
                modifier = Modifier.weight(1f),
                onClick = { onNavigate(TurboNavDestination.NETWORK_VPN) }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            FeatureTile(
                title = if (isVietnamese) "Dọn dẹp RAM / Rác" else "RAM & Storage Clean",
                subtitle = if (isVietnamese) "Quét & Giải phóng" else "Memory booster",
                icon = Icons.Default.CleaningServices,
                accentColor = ElectricAmber,
                modifier = Modifier.weight(1f),
                onClick = { onNavigate(TurboNavDestination.CLEANER) }
            )
            FeatureTile(
                title = if (isVietnamese) "Tối ưu cảm ứng" else "Touch Optimization",
                subtitle = if (isVietnamese) "Đo độ trễ phản hồi" else "Latency & Shield",
                icon = Icons.Default.TouchApp,
                accentColor = PurpleCyber,
                modifier = Modifier.weight(1f),
                onClick = { onNavigate(TurboNavDestination.TOUCH_OPTIMIZER) }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            FeatureTile(
                title = if (isVietnamese) "Thống kê trận đấu" else "Gaming Stats",
                subtitle = if (isVietnamese) "Thời gian & Lịch sử" else "History & charts",
                icon = Icons.Default.Insights,
                accentColor = Color(0xFF40C4FF),
                modifier = Modifier.weight(1f),
                onClick = { onNavigate(TurboNavDestination.STATISTICS) }
            )
            FeatureTile(
                title = if (isVietnamese) "Cài đặt & Thanh nổi" else "Turbo Settings",
                subtitle = if (isVietnamese) "Tùy biến hiển thị" else "Floating overlay HUD",
                icon = Icons.Default.Settings,
                accentColor = Color(0xFFFF80AB),
                modifier = Modifier.weight(1f),
                onClick = { onNavigate(TurboNavDestination.SETTINGS) }
            )
        }
    }
}

@Composable
private fun FeatureTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val glassColors = LocalGlassColors.current

    GlassCard(
        modifier = modifier.height(90.dp),
        shape = RoundedCornerShape(18.dp),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = glassColors.textPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = glassColors.textSecondary,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun ThermalAndNetworkCard(
    stats: DeviceHardwareStats,
    isVietnamese: Boolean,
    onTestNetwork: () -> Unit
) {
    val glassColors = LocalGlassColors.current

    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(stats.thermalStatus.colorHex).copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (stats.batteryTempCelsius > 42f) "🔥" else "❄️",
                            fontSize = 18.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = if (isVietnamese) "Bảo vệ Nhiệt độ: ${stats.thermalStatus.titleVn}" else "Thermal Protection: ${stats.thermalStatus.titleEn}",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isVietnamese) "Tốc độ tải: ${stats.downloadSpeedMbps.toInt()} Mbps • Jitter: ${stats.jitterMs}ms" else "Download: ${stats.downloadSpeedMbps.toInt()} Mbps • Jitter: ${stats.jitterMs}ms",
                            color = glassColors.textSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color.White,
                    modifier = Modifier.clickable { onTestNetwork() }
                ) {
                    Text(
                        text = if (isVietnamese) "Kiểm tra" else "Test",
                        color = Color.Black,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}
