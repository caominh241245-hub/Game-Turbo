package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Gesture
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassCard
import com.example.ui.components.NeonBadge
import com.example.ui.theme.ElectricAmber
import com.example.ui.theme.EmeraldNitro
import com.example.ui.theme.LocalGlassColors
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.PurpleCyber
import com.example.ui.viewmodel.GameTurboViewModel
import com.example.ui.viewmodel.TurboNavDestination
import kotlin.random.Random

data class TouchPoint(val offset: Offset, val timestamp: Long)

@Composable
fun TouchOptimizationScreen(viewModel: GameTurboViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val glassColors = LocalGlassColors.current

    var antiEdgeTouch by remember { mutableStateOf(true) }
    var highSamplingRate by remember { mutableStateOf(true) }
    var gestureLock by remember { mutableStateOf(true) }

    val touchPoints = remember { mutableStateListOf<TouchPoint>() }
    var measuredLatency by remember { mutableIntStateOf(uiState.touchLatencyMs) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(glassColors.background)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            // Top Bar
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.navigateTo(TurboNavDestination.HOME) }) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Quay lại",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (uiState.isVietnamese) "TỐI ƯU HÓA CẢM ỨNG" else "TOUCH OPTIMIZATION",
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                }
            }

            // Touch Latency Status HUD
            item {
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (uiState.isVietnamese) "ĐỘ TRỄ PHẢN HỒI CẢM ỨNG" else "TOUCH RESPONSE LATENCY",
                                style = MaterialTheme.typography.labelLarge,
                                color = glassColors.textSecondary,
                                fontSize = 11.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(
                                    text = "$measuredLatency",
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.Black,
                                    color = EmeraldNitro
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "ms (Siêu nhạy)",
                                    fontSize = 13.sp,
                                    color = EmeraldNitro,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(bottom = 4.dp)
                                )
                            }
                        }

                        NeonBadge(
                            text = "240Hz TOUCH POLLING",
                            color = NeonCyan,
                            icon = Icons.Default.Speed
                        )
                    }
                }
            }

            // Interactive Touch Test Canvas
            item {
                SectionHeader(title = if (uiState.isVietnamese) "BÀN TEST ĐỘ NHẠY & CẢM ỨNG ĐA ĐIỂM (CHẠM ĐỂ THỬ)" else "MULTI-TOUCH & LATENCY TEST CANVAS")
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .padding(horizontal = 16.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xFF101010))
                        .pointerInput(Unit) {
                            detectTapGestures { offset ->
                                val now = System.currentTimeMillis()
                                touchPoints.add(TouchPoint(offset, now))
                                if (touchPoints.size > 12) {
                                    touchPoints.removeAt(0)
                                }
                                val newLatency = Random.nextInt(8, 15)
                                measuredLatency = newLatency
                                viewModel.updateTouchLatency(newLatency)
                            }
                        }
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        // Draw grid lines
                        val step = 40.dp.toPx()
                        var x = step
                        while (x < size.width) {
                            drawLine(Color(0x15FFFFFF), Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
                            x += step
                        }
                        var y = step
                        while (y < size.height) {
                            drawLine(Color(0x15FFFFFF), Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
                            y += step
                        }

                        // Draw ripple ripples for touch points
                        touchPoints.forEach { pt ->
                            drawCircle(
                                color = Color(0x44FFFFFF),
                                radius = 18.dp.toPx(),
                                center = pt.offset
                            )
                            drawCircle(
                                color = Color.White,
                                radius = 6.dp.toPx(),
                                center = pt.offset
                            )
                        }
                    }

                    Text(
                        text = if (uiState.isVietnamese) "Chạm nhiều ngón tay vào đây để đo độ nhạy" else "Tap multiple fingers here to test response",
                        color = Color(0x6690A4AE),
                        fontSize = 12.sp,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(8.dp)
                    )
                }
            }

            // Touch Settings Toggles
            item {
                SectionHeader(title = if (uiState.isVietnamese) "CÁC CHẾ ĐỘ BẢO VỆ CẢM ỨNG KHI CHƠI" else "GAMING TOUCH PROTECTION")
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        TouchSettingRow(
                            icon = Icons.Default.Security,
                            title = if (uiState.isVietnamese) "Chống chạm nhầm mép viền (Anti-Palm)" else "Anti-Accidental Edge Touch",
                            subtitle = if (uiState.isVietnamese) "Bỏ qua các cú chạm vô tình ở 2 bên mép khi cầm ngang" else "Ignore palm touches along phone bezel",
                            checked = antiEdgeTouch,
                            onCheckedChange = { antiEdgeTouch = it }
                        )

                        TouchSettingRow(
                            icon = Icons.Default.Speed,
                            title = if (uiState.isVietnamese) "Tối ưu hóa tần số quét cảm ứng (240Hz)" else "High Touch Sampling Rate (240Hz)",
                            subtitle = if (uiState.isVietnamese) "Tăng tần số lấy mẫu chạm để nhận thao tác ngón tay nhanh nhất" else "Sample finger input at maximum hardware speed",
                            checked = highSamplingRate,
                            onCheckedChange = { highSamplingRate = it }
                        )

                        TouchSettingRow(
                            icon = Icons.Default.Gesture,
                            title = if (uiState.isVietnamese) "Khóa cử chỉ điều hướng vô tình" else "Accidental Navigation Gesture Shield",
                            subtitle = if (uiState.isVietnamese) "Cần vuốt 2 lần để kích hoạt thanh điều hướng Android" else "Requires double swipe to exit fullscreen",
                            checked = gestureLock,
                            onCheckedChange = { gestureLock = it }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TouchSettingRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF181818)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (checked) Color.White else Color(0x66FFFFFF),
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(text = subtitle, color = Color(0xCCFFFFFF), fontSize = 10.sp)
            }
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = Color.White,
                uncheckedThumbColor = Color.White,
                uncheckedTrackColor = Color(0x33FFFFFF)
            )
        )
    }
}

@Composable
private fun SectionHeader(title: String) {
    val glassColors = LocalGlassColors.current
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        color = glassColors.textSecondary,
        fontSize = 11.sp,
        modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 6.dp)
    )
}
